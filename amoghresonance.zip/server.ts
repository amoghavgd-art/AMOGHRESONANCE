import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '50mb' }));

// Server-side Gemini initialization with telemetry header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

export interface Turn {
  speaker: string;
  text: string;
  style?: string;
  burst?: string;
}

export interface Segment {
  segmentId: number;
  title: string;
  summary?: string;
  turns: Turn[];
}

export interface BroadcastScript {
  showTitle: string;
  stationName: string;
  frequency: string;
  tagline: string;
  targetDurationMinutes: number;
  tone: string;
  musicVibe: string;
  hosts: {
    host1: { name: string; voice: string; persona: string };
    host2: { name: string; voice: string; persona: string };
  };
  segments: Segment[];
  editorialNotes: string;
}

// Generate the complete multi-host radio broadcast script
app.post('/api/broadcast/generate-script', async (req: Request, res: Response) => {
  try {
    const {
      topic,
      targetDurationMinutes = 5,
      tone = 'Conversational Deep Dive (NotebookLM style)',
      hostDuo = 'devon-maya',
      musicVibe = 'lofi-chill',
      customHost1,
      customHost2,
    } = req.body;

    if (!topic || typeof topic !== 'string' || !topic.trim()) {
      return res.status(400).json({ error: 'Topic or idea input is required.' });
    }

    // Map duo selection to voice pairings supported by gemini-3.8-flash-tts ('Puck', 'Charon', 'Kore', 'Fenrir', 'Zephyr')
    let host1Name = 'Devon';
    let host1Voice = 'Zephyr';
    let host1Persona = 'Deep, thoughtful, analytical host who breaks complex ideas into relatable mental models';

    let host2Name = 'Maya';
    let host2Voice = 'Kore';
    let host2Persona = 'Curious, energetic co-host who asks penetrating questions, interjects, and adds witty counter-perspectives';

    if (hostDuo === 'midnight-noir') {
      host1Name = 'Kieran';
      host1Voice = 'Charon';
      host1Persona = 'Warm, resonant late-night broadcaster with an introspective, intimate cadence';
      host2Name = 'Mara';
      host2Voice = 'Fenrir';
      host2Persona = 'Astute, poetic investigator with dry wit and sharp insight';
    } else if (hostDuo === 'electric-banter') {
      host1Name = 'Alex';
      host1Voice = 'Puck';
      host1Persona = 'Spirited, fast-paced presenter with vibrant energy and spontaneous curiosity';
      host2Name = 'Elena';
      host2Voice = 'Kore';
      host2Persona = 'Sharp, grounded co-anchor who keeps the broadcast grounded with razor-sharp facts';
    } else if (hostDuo === 'custom-duo' || customHost1 || customHost2) {
      if (customHost1?.name) host1Name = customHost1.name;
      if (customHost1?.voice) host1Voice = customHost1.voice;
      if (customHost2?.name) host2Name = customHost2.name;
      if (customHost2?.voice) host2Voice = customHost2.voice;
    }

    // Determine segments count based on requested duration (3 to 15 mins)
    // 3 min = 2 segments, 5 min = 3 segments, 8 min = 4 segments, 12 min = 5 segments, 15 min = 6 segments
    const segmentCount = targetDurationMinutes <= 3 ? 2 : targetDurationMinutes <= 6 ? 3 : targetDurationMinutes <= 10 ? 4 : 5;

    const systemPrompt = `You are the lead executive producer for AMOGH RESONANCE (AMOGH RADIO), the premier neural broadcast network known for immersive, ultra-natural radio shows modeled after Google NotebookLM's beloved audio deep dives.

Your mission: Transform the user's idea, topic, notes, or research into a captivating radio broadcast show.

Requirements for the Broadcast:
1. Two distinct hosts: ${host1Name} (Voice: ${host1Voice}) and ${host2Name} (Voice: ${host2Voice}).
2. Real conversational flow: Include natural backchanneling like |yeah|, |mhm|, |right|, and emotional cues like <laugh>, <breath>, <chuckle>, <sigh> to make the delivery sound astonishingly human and spontaneous.
3. NotebookLM dynamic: They interrupt each other politely, complete each other's sentences, use vivid analogies, share moments of genuine wonder, and challenge easy assumptions.
4. Professional Station identity: Weave in authentic radio station flair ("You're tuned into AMOGH RESONANCE, broadcasting on 104.7 FM Neural Core", "Welcome back to the signal", etc.).
5. Create exactly ${segmentCount} cohesive segments.
   - Segment 1: Cold Open & The Hook (gripping entry, setting the stage, provocative riddle or hook)
   - Middle Segments: The Deep Dive, Unpacking Hidden Layers, Controversies & Counter-Intuitions
   - Final Segment: The Big Picture Takeaway, Memorable Philosophical Resonance & Station Sign-off.
6. Target duration is approx ${targetDurationMinutes} minutes total. Each turn should have natural dialogue (2 to 5 sentences per turn). Provide around 4 to 7 turns per segment.

Return ONLY a valid JSON object matching this TypeScript interface without markdown wrappers:
{
  "showTitle": string,
  "stationName": "AMOGH RESONANCE",
  "frequency": "104.7 FM",
  "tagline": string,
  "targetDurationMinutes": number,
  "tone": string,
  "musicVibe": "${musicVibe}",
  "hosts": {
    "host1": { "name": "${host1Name}", "voice": "${host1Voice}", "persona": "${host1Persona}" },
    "host2": { "name": "${host2Name}", "voice": "${host2Voice}", "persona": "${host2Persona}" }
  },
  "segments": [
    {
      "segmentId": number,
      "title": string,
      "summary": string,
      "turns": [
        {
          "speaker": "${host1Name}" | "${host2Name}",
          "text": string,
          "style": string
        }
      ]
    }
  ],
  "editorialNotes": string
}`;

    // Attempt generation with fallback cascade (prioritizing fast and available flash-lite)
    const candidateModels = ['gemini-3.1-flash-lite', 'gemini-3.8-flash', 'gemini-flash-latest'];
    let responseText = '';
    let lastError: any = null;

    for (const modelName of candidateModels) {
      try {
        console.log(`[Script Generator] Trying model: ${modelName}...`);
        const response = await ai.models.generateContent({
          model: modelName,
          contents: `Generate the broadcast script for AMOGH RESONANCE on this subject:\n\n${topic}`,
          config: {
            systemInstruction: systemPrompt,
            responseMimeType: 'application/json',
            temperature: 0.85,
          },
        });
        if (response.text) {
          responseText = response.text.trim();
          console.log(`[Script Generator] Successfully generated script using ${modelName}`);
          break;
        }
      } catch (err: any) {
        console.warn(`[Script Generator] Model ${modelName} failed:`, err?.message || err);
        lastError = err;
      }
    }

    if (!responseText) {
      throw lastError || new Error('All candidate models failed to generate script.');
    }

    // Strip markdown wrappers if present (e.g. ```json ... ```)
    let cleanJson = responseText;
    if (cleanJson.startsWith('```')) {
      cleanJson = cleanJson.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '');
    }

    const script: BroadcastScript = JSON.parse(cleanJson);
    return res.json(script);
  } catch (error: any) {
    console.error('Error generating radio script:', error);
    return res.status(500).json({
      error: 'Failed to generate broadcast script.',
      details: error?.message || String(error),
    });
  }
});

// In-memory cache for synthesized audio to guarantee 0ms latency on repeated turns and previews
const ttsAudioCache = new Map<string, string>();

function hashString(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash |= 0;
  }
  return hash.toString(36);
}

// Endpoint to audition individual realistic voices with ultra-low latency
app.post('/api/broadcast/preview-voice', async (req: Request, res: Response) => {
  try {
    const { voice = 'Zephyr', text } = req.body;
    const defaultTexts: Record<string, string> = {
      Zephyr: "Welcome to AMOGH RESONANCE on 104.7 FM. I'm Devon, analyzing the deepest patterns of reality.",
      Kore: "Hey there! Maya here on 104.7 FM. Let's dig beneath the surface and uncover what really matters.",
      Puck: "Brilliant to have you with us! Alex here on AMOGH RESONANCE, ready for some high-velocity exploration.",
      Charon: "Midnight on 104.7 FM. This is Kieran. Settle in, let the static fade, and listen closely.",
      Fenrir: "Mara on AMOGH RESONANCE. Questioning assumptions, dissecting paradoxes, and following the evidence.",
    };

    const sampleText = text || defaultTexts[voice] || defaultTexts.Zephyr;
    const cacheKey = `voice_${voice}_${hashString(sampleText)}`;

    if (ttsAudioCache.has(cacheKey)) {
      return res.json({
        audioBase64: ttsAudioCache.get(cacheKey),
        mimeType: 'audio/wav',
        sampleRate: 24000,
        voice,
        cached: true,
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: sampleText,
              speechMetadata: {
                style: 'Crisp, charismatic, broadcast-grade radio presenter',
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice },
          },
        },
      },
    });

    const audioBase64 = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (audioBase64) {
      ttsAudioCache.set(cacheKey, audioBase64);
      return res.json({
        audioBase64,
        mimeType: 'audio/wav',
        sampleRate: 24000,
        voice,
        cached: false,
      });
    }

    return res.status(500).json({ error: 'No audio generated' });
  } catch (error: any) {
    console.warn('Voice preview error:', error?.message);
    return res.status(500).json({ error: 'Voice preview failed', details: error?.message });
  }
});

// Endpoint to audition a duo banter exchange
app.post('/api/broadcast/preview-duo', async (req: Request, res: Response) => {
  try {
    const {
      host1Name = 'Devon',
      host1Voice = 'Zephyr',
      host2Name = 'Maya',
      host2Voice = 'Kore',
    } = req.body;

    const sampleExchange = [
      { speaker: host1Name, text: `You're tuned into AMOGH RESONANCE 104.7 FM. I'm ${host1Name}.` },
      { speaker: host2Name, text: `And I'm ${host2Name}! <chuckle> Ready to broadcast with ultra-realistic neural speech.` },
    ];

    const cacheKey = `duo_${host1Voice}_${host2Voice}_${hashString(JSON.stringify(sampleExchange))}`;
    if (ttsAudioCache.has(cacheKey)) {
      return res.json({
        audioBase64: ttsAudioCache.get(cacheKey),
        mimeType: 'audio/wav',
        sampleRate: 24000,
        cached: true,
      });
    }

    const formattedParts = sampleExchange.map((turn) => ({
      text: `${turn.speaker}: ${turn.text}`,
      speechMetadata: { speaker: turn.speaker },
    }));

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-tts',
      contents: [{ role: 'user', parts: formattedParts }],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          multiSpeakerVoiceConfig: {
            speakerVoiceConfigs: [
              {
                speaker: host1Name,
                voiceConfig: { prebuiltVoiceConfig: { voiceName: host1Voice } },
              },
              {
                speaker: host2Name,
                voiceConfig: { prebuiltVoiceConfig: { voiceName: host2Voice } },
              },
            ],
          },
        },
      },
    });

    const audioBase64 = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (audioBase64) {
      ttsAudioCache.set(cacheKey, audioBase64);
      return res.json({
        audioBase64,
        mimeType: 'audio/wav',
        sampleRate: 24000,
        cached: false,
      });
    }

    return res.status(500).json({ error: 'Duo preview failed' });
  } catch (error: any) {
    console.warn('Duo preview notice:', error?.message);
    return res.status(500).json({ error: 'Duo preview failed', details: error?.message });
  }
});

// Synthesize speech for a segment with adaptive low-latency caching
app.post('/api/broadcast/synthesize-segment', async (req: Request, res: Response) => {
  try {
    const {
      turns,
      host1,
      host2,
      host1Voice = 'Zephyr',
      host2Voice = 'Kore',
      mode = 'studio-master', // 'low-latency' | 'studio-master'
    } = req.body;

    if (!turns || !Array.isArray(turns) || turns.length === 0) {
      return res.status(400).json({ error: 'Valid turns array is required.' });
    }

    const host1Name = host1?.name || 'Devon';
    const host2Name = host2?.name || 'Maya';

    // Check in-memory cache first for instant (0ms) response
    const cacheKey = `seg_${host1Voice}_${host2Voice}_${hashString(
      JSON.stringify(turns.map((t: Turn) => `${t.speaker}:${t.text}`))
    )}`;

    if (ttsAudioCache.has(cacheKey)) {
      console.log(`[TTS Engine] Cache hit for segment (${turns.length} turns)`);
      return res.json({
        audioBase64: ttsAudioCache.get(cacheKey),
        mimeType: 'audio/wav',
        sampleRate: 24000,
        model: 'cache',
        mode: 'neural-wav',
        cached: true,
      });
    }

    // Clean speaker prefix to avoid duplicate "Alex: Alex: ..."
    const formattedParts = turns.map((turn: Turn) => {
      const isHost1 = turn.speaker.toLowerCase().includes(host1Name.toLowerCase());
      const speakerId = isHost1 ? host1Name : host2Name;
      const hostPersona = isHost1 ? host1?.persona : host2?.persona;
      const hostStyle = turn.style || (isHost1
        ? `${hostPersona || 'Charismatic radio host'}, warm, natural presence`
        : `${hostPersona || 'Curious engaging co-host'}, articulate and lively`);

      // Strip any existing speaker label from dialogue text
      const cleanText = turn.text.replace(new RegExp(`^${speakerId}:?\\s*`, 'i'), '').trim();

      return {
        text: `${speakerId}: ${cleanText}`,
        speechMetadata: {
          speaker: speakerId,
          style: hostStyle,
        },
      };
    });

    let audioBase64: string | undefined;
    let ttsModelUsed: string = 'gemini-3.8-flash-tts';

    // If ultra low-latency mode is selected, try gemini-3.8-flash-lite-tts first
    if (mode === 'low-latency') {
      try {
        const combinedScript = formattedParts.map((p) => p.text).join('\n\n');
        const liteRes = await ai.models.generateContent({
          model: 'gemini-3.8-flash-lite-tts',
          contents: [
            {
              role: 'user',
              parts: [
                {
                  text: combinedScript,
                  speechMetadata: {
                    style: 'Dynamic, natural radio broadcast conversation between two hosts',
                  },
                },
              ],
            },
          ],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: host1Voice || 'Zephyr' },
              },
            },
          },
        });
        audioBase64 = liteRes.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (audioBase64) {
          ttsModelUsed = 'gemini-3.8-flash-lite-tts';
        }
      } catch (liteErr: any) {
        console.warn('[TTS Low-Latency] Fallback to multi-speaker:', liteErr?.message);
      }
    }

    // Standard Studio Master path: gemini-3.8-flash-tts multi-speaker
    if (!audioBase64) {
      try {
        const ttsResponse = await ai.models.generateContent({
          model: 'gemini-3.8-flash-tts',
          contents: [
            {
              role: 'user',
              parts: formattedParts,
            },
          ],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              multiSpeakerVoiceConfig: {
                speakerVoiceConfigs: [
                  {
                    speaker: host1Name,
                    voiceConfig: {
                      prebuiltVoiceConfig: { voiceName: host1Voice },
                    },
                  },
                  {
                    speaker: host2Name,
                    voiceConfig: {
                      prebuiltVoiceConfig: { voiceName: host2Voice },
                    },
                  },
                ],
              },
            },
          },
        });

        audioBase64 = ttsResponse.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        ttsModelUsed = 'gemini-3.8-flash-tts';
      } catch (ttsErr: any) {
        console.warn('[TTS Multi-Speaker] Notice:', ttsErr?.message || 'Retrying with flash-lite-tts...');

        // Fallback 1: gemini-3.8-flash-lite-tts
        try {
          const combinedScript = formattedParts.map((p) => p.text).join('\n\n');
          const fallbackResponse = await ai.models.generateContent({
            model: 'gemini-3.8-flash-lite-tts',
            contents: [
              {
                role: 'user',
                parts: [
                  {
                    text: combinedScript,
                    speechMetadata: {
                      style: 'Radio broadcast conversation with dual-speaker rhythm',
                    },
                  },
                ],
              },
            ],
            config: {
              responseModalities: ['AUDIO'],
              speechConfig: {
                voiceConfig: {
                  prebuiltVoiceConfig: { voiceName: host1Voice || 'Zephyr' },
                },
              },
            },
          });

          audioBase64 = fallbackResponse.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
          ttsModelUsed = 'gemini-3.8-flash-lite-tts';
        } catch (liteErr: any) {
          console.warn('[TTS] Lite fallback error:', liteErr?.message);
        }
      }
    }

    if (audioBase64) {
      // Save in cache for instantaneous replay and WAV export
      ttsAudioCache.set(cacheKey, audioBase64);

      return res.json({
        audioBase64,
        mimeType: 'audio/wav',
        sampleRate: 24000,
        model: ttsModelUsed,
        mode: 'neural-wav',
        cached: false,
      });
    }

    // Graceful fallback to client-side studio neural speech synthesis
    return res.json({
      mode: 'client-speech',
      fallback: true,
      quotaExceeded: true,
      sampleRate: 24000,
      message: 'Gemini TTS rate limit reached. Seamlessly streaming with Studio Neural Speech Engine.',
    });
  } catch (error: any) {
    return res.json({
      mode: 'client-speech',
      fallback: true,
      error: error?.message || 'Synthesis fallback active',
    });
  }
});

// Google Drive integration: List files
app.get('/api/drive/files', async (req: Request, res: Response) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Missing or invalid Authorization header.' });
    }
    const token = authHeader.split(' ')[1];

    const driveUrl =
      "https://www.googleapis.com/drive/v3/files?q=mimeType='application/vnd.google-apps.document' or mimeType='text/plain' or mimeType='application/pdf'&fields=files(id,name,mimeType,modifiedTime,size)&pageSize=25&orderBy=modifiedTime desc";

    const driveResponse = await fetch(driveUrl, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!driveResponse.ok) {
      const errText = await driveResponse.text();
      return res.status(driveResponse.status).json({ error: 'Drive API error', details: errText });
    }

    const data = await driveResponse.json();
    return res.json(data);
  } catch (err: any) {
    console.error('Error listing drive files:', err);
    return res.status(500).json({ error: 'Failed to fetch Drive files', details: err?.message });
  }
});

// Google Drive integration: Read file text content
app.get('/api/drive/file-content', async (req: Request, res: Response) => {
  try {
    const authHeader = req.headers.authorization;
    const fileId = req.query.fileId as string;
    const mimeType = req.query.mimeType as string;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Missing or invalid Authorization header.' });
    }
    if (!fileId) {
      return res.status(400).json({ error: 'Missing fileId parameter.' });
    }

    const token = authHeader.split(' ')[1];
    let fetchUrl = '';

    if (mimeType === 'application/vnd.google-apps.document') {
      // Export Google Doc as plain text
      fetchUrl = `https://www.googleapis.com/drive/v3/files/${fileId}/export?mimeType=text/plain`;
    } else {
      // Direct file content download
      fetchUrl = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
    }

    const fileRes = await fetch(fetchUrl, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!fileRes.ok) {
      const errText = await fileRes.text();
      return res.status(fileRes.status).json({ error: 'Failed to export/fetch file content', details: errText });
    }

    const contentText = await fileRes.text();
    return res.json({ content: contentText });
  } catch (err: any) {
    console.error('Error reading drive file:', err);
    return res.status(500).json({ error: 'Failed to read Drive file content', details: err?.message });
  }
});

// Health check
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    station: 'AMOGH RESONANCE 104.7 FM',
    service: 'Neural Radio Broadcast Engine',
  });
});

// Broadcast & Neural Voice Station Status
app.get('/api/broadcast/status', (req: Request, res: Response) => {
  const hasKey = !!process.env.GEMINI_API_KEY;
  res.json({
    status: 'online',
    station: 'AMOGH RESONANCE',
    frequency: '104.7 FM',
    connected: hasKey,
    neuralEngines: [
      { id: 'gemini-3.8-flash-tts', type: 'flagship-multispeaker', description: 'Dual-speaker screenplay with natural laughs, breaths, and backchanneling' },
      { id: 'gemini-3.8-flash-lite-tts', type: 'ultra-low-latency', description: 'Sub-2s latency fast-track neural speech synthesis' },
    ],
    supportedVoices: [
      { id: 'Zephyr', name: 'Devon', tone: 'Analytical, smooth, modern baritone', style: 'Analytical thinker' },
      { id: 'Kore', name: 'Maya', tone: 'Warm, expressive, high-clarity female host', style: 'Curious co-host' },
      { id: 'Puck', name: 'Alex', tone: 'Charismatic, lively British-leaning presenter', style: 'High energy' },
      { id: 'Charon', name: 'Kieran', tone: 'Deep, rich, resonant late-night baritone', style: 'Nocturnal deep dive' },
      { id: 'Fenrir', name: 'Mara', tone: 'Sharp, intellectual, investigative gravitas', style: 'Inquisitive journalist' },
    ],
    cacheSize: ttsAudioCache.size,
  });
});

// Vite or Static file serving
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AMOGH RESONANCE Engine broadcasting on http://0.0.0.0:${PORT}`);
  });
}

startServer();
