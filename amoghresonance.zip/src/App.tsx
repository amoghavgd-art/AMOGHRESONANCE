/**
 * AMOGH RESONANCE — Broadcast-Grade Neural Auditory Synthesis
 * Inspired by Google NotebookLM Audio Deep Dives, powered by Gemini 3.8 & Web Audio API.
 */

import React, { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import { initAuth, setAccessToken } from './lib/firebase';
import { BroadcastScript, MusicVibe, Segment } from './types/broadcast';
import { broadcastAudioEngine } from './lib/audioEngine';
import { Header } from './components/Header';
import { BroadcastStudioInput } from './components/BroadcastStudioInput';
import { BroadcastDeck } from './components/BroadcastDeck';
import { GoogleDrivePicker } from './components/GoogleDrivePicker';
import { CuratedBroadcasts } from './components/CuratedBroadcasts';
import { Radio, AlertCircle, Sparkles } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [hasDriveAccess, setHasDriveAccess] = useState(false);
  const [isDriveModalOpen, setIsDriveModalOpen] = useState(false);
  const [importedDocTitle, setImportedDocTitle] = useState<string | null>(null);
  const [importedDocText, setImportedDocText] = useState<string | null>(null);

  // Active show state
  const [activeScript, setActiveScript] = useState<BroadcastScript | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStep, setGenerationStep] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Initialize Auth state
  useEffect(() => {
    const unsubscribe = initAuth(
      (currentUser, token) => {
        setUser(currentUser);
        if (token) {
          setAccessToken(token);
          setHasDriveAccess(true);
        }
      },
      () => {
        setUser(null);
        setHasDriveAccess(false);
      }
    );

    return () => {
      if (typeof unsubscribe === 'function') {
        unsubscribe();
      }
    };
  }, []);

  const handleAuthSuccess = (authenticatedUser: User, token: string) => {
    setUser(authenticatedUser);
    setAccessToken(token);
    setHasDriveAccess(true);
  };

  const handleDocImported = (title: string, text: string) => {
    setImportedDocTitle(title);
    setImportedDocText(text);
  };

  // Synthesize and stream broadcast
  const handleGenerateBroadcast = async (params: {
    topic: string;
    targetDurationMinutes: number;
    tone: string;
    hostDuo: string;
    musicVibe: MusicVibe;
    synthesisMode: 'low-latency' | 'studio-master';
    customHost1?: { name: string; voice: string };
    customHost2?: { name: string; voice: string };
  }) => {
    try {
      setIsGenerating(true);
      setErrorMessage(null);
      setGenerationStep('Tuning broadcast transmitter & station frequencies (104.7 FM)...');

      // Play AMOGH RESONANCE signature station chime
      broadcastAudioEngine.playStationIdent();

      setGenerationStep('Generating broadcast screenplay & host banter with Gemini...');

      // 1. Generate full script
      const scriptRes = await fetch('/api/broadcast/generate-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });

      if (!scriptRes.ok) {
        const errData = await scriptRes.json().catch(() => ({}));
        throw new Error(errData.error || `Script generation failed (HTTP ${scriptRes.status})`);
      }

      const script: BroadcastScript = await scriptRes.json();
      setActiveScript(script);

      // 2. Start generative background soundtrack
      broadcastAudioEngine.clearSegments();
      broadcastAudioEngine.startBackgroundMusic(params.musicVibe);

      // 3. Synthesize Segment 1 immediately for instant playback
      setGenerationStep(
        params.synthesisMode === 'low-latency'
          ? `Fast-Tracking neural speech for ${script.hosts.host1.name} & ${script.hosts.host2.name}...`
          : `Mastering multi-speaker audio for ${script.hosts.host1.name} & ${script.hosts.host2.name}...`
      );

      const firstSeg = script.segments[0];
      const ttsRes = await fetch('/api/broadcast/synthesize-segment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          turns: firstSeg.turns,
          host1: script.hosts.host1,
          host2: script.hosts.host2,
          host1Voice: script.hosts.host1.voice,
          host2Voice: script.hosts.host2.voice,
          mode: params.synthesisMode,
        }),
      });

      const ttsData = await ttsRes.json();
      if (ttsData.audioBase64) {
        await broadcastAudioEngine.loadSegmentAudio(0, ttsData.audioBase64);
        // Start streaming Segment 1 right away!
        broadcastAudioEngine.playSegment(0, 0);
        synthesizeRemainingSegments(script, params.synthesisMode);
      } else {
        // Seamlessly stream via Studio Neural Speech Engine with background music & ducking
        broadcastAudioEngine.startSpeechSynthesisShow(script);
      }

      setIsGenerating(false);
    } catch (err: any) {
      console.error('Broadcast generation error:', err);
      setErrorMessage(err?.message || 'Failed to generate broadcast. Please try again.');
      setIsGenerating(false);
    }
  };

  // Asynchronously synthesizes remaining segments so playback never hitches
  const synthesizeRemainingSegments = async (
    script: BroadcastScript,
    mode: 'low-latency' | 'studio-master' = 'studio-master'
  ) => {
    for (let i = 1; i < script.segments.length; i++) {
      try {
        // Stagger requests gracefully while user is enjoying the ongoing broadcast
        await new Promise((resolve) => setTimeout(resolve, 1500));

        const seg = script.segments[i];
        const res = await fetch('/api/broadcast/synthesize-segment', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            turns: seg.turns,
            host1: script.hosts.host1,
            host2: script.hosts.host2,
            host1Voice: script.hosts.host1.voice,
            host2Voice: script.hosts.host2.voice,
            mode,
          }),
        });

        if (res.ok) {
          const data = await res.json();
          if (data.audioBase64) {
            await broadcastAudioEngine.loadSegmentAudio(i, data.audioBase64);
          }
        }
      } catch (e) {
        console.warn(`Segment ${i} synthesis failed in background:`, e);
      }
    }
  };

  // Stream a curated premier broadcast from the station archive
  const handleSelectCuratedShow = async (curated: BroadcastScript) => {
    try {
      setIsGenerating(true);
      setErrorMessage(null);
      setGenerationStep(`Loading premier broadcast: "${curated.showTitle}"...`);

      broadcastAudioEngine.playStationIdent();
      setActiveScript(curated);
      broadcastAudioEngine.clearSegments();
      broadcastAudioEngine.startBackgroundMusic(curated.musicVibe as MusicVibe);

      // Synthesize first segment
      setGenerationStep('Synthesizing studio voices for premier archive...');
      const res = await fetch('/api/broadcast/synthesize-segment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          turns: curated.segments[0].turns,
          host1: curated.hosts.host1,
          host2: curated.hosts.host2,
          host1Voice: curated.hosts.host1.voice,
          host2Voice: curated.hosts.host2.voice,
          mode: 'studio-master',
        }),
      });

      const data = await res.json();
      if (data.audioBase64) {
        await broadcastAudioEngine.loadSegmentAudio(0, data.audioBase64);
        broadcastAudioEngine.playSegment(0, 0);
        synthesizeRemainingSegments(curated, 'studio-master');
      } else {
        // Fallback to studio speech synthesis
        broadcastAudioEngine.startSpeechSynthesisShow(curated);
      }

      setIsGenerating(false);
    } catch (err: any) {
      console.error('Curated show loading error:', err);
      setErrorMessage(err?.message || 'Failed to load premier broadcast.');
      setIsGenerating(false);
    }
  };

  const handleReset = () => {
    broadcastAudioEngine.pause();
    broadcastAudioEngine.stopBackgroundMusic();
    setActiveScript(null);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-amber-500 selection:text-zinc-950">
      {/* Station Header */}
      <Header
        user={user}
        hasDriveAccess={hasDriveAccess}
        onOpenDriveModal={() => setIsDriveModalOpen(true)}
        onAuthSuccess={handleAuthSuccess}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 flex flex-col items-center">
        {/* Error notification */}
        {errorMessage && (
          <div className="w-full max-w-4xl mb-6 p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center justify-between animate-in fade-in">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              type="button"
              onClick={() => setErrorMessage(null)}
              className="px-2 py-1 rounded bg-rose-500/20 hover:bg-rose-500/30 text-rose-200"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* View Switcher: Studio Input vs Active Broadcast Deck */}
        {activeScript ? (
          <BroadcastDeck
            script={activeScript}
            onReset={handleReset}
          />
        ) : (
          <div className="w-full space-y-8">
            <BroadcastStudioInput
              onGenerate={handleGenerateBroadcast}
              isGenerating={isGenerating}
              generationStep={generationStep}
              onOpenDriveModal={() => setIsDriveModalOpen(true)}
              hasDriveAccess={hasDriveAccess}
              importedDocTitle={importedDocTitle}
              importedText={importedDocText}
            />

            {/* Ready-to-listen curated shows archive */}
            <CuratedBroadcasts
              onSelectBroadcast={handleSelectCuratedShow}
              disabled={isGenerating}
            />
          </div>
        )}
      </main>

      {/* Google Drive Document Picker Modal */}
      <GoogleDrivePicker
        isOpen={isDriveModalOpen}
        onClose={() => setIsDriveModalOpen(false)}
        onSelectDoc={handleDocImported}
      />

      {/* Footer */}
      <footer className="w-full border-t border-zinc-900 bg-zinc-950/90 py-5 text-center text-xs text-zinc-500 font-mono">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>AMOGH RESONANCE 104.7 FM • Broadcast-Grade Neural Auditory Synthesis</span>
          <span className="text-[11px] text-zinc-600">
            Powered by Gemini 3.8 Neural Audio Engine & Google Workspace
          </span>
        </div>
      </footer>
    </div>
  );
}
