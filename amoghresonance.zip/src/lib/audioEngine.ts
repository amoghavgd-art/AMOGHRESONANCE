/**
 * AMOGH RESONANCE Studio Broadcast Audio Engine
 * High-fidelity Web Audio API engine providing broadcast master compression,
 * dynamic generative background music with automatic sidechain ducking,
 * station sonic idents, and multi-segment seamless playback.
 */

import { MusicVibe } from '../types/broadcast';

class BroadcastAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private voiceGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private duckingGain: GainNode | null = null;
  private analyser: AnalyserNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;

  // Active voice source
  private currentSource: AudioBufferSourceNode | null = null;
  private isVoicePlaying: boolean = false;
  private voiceStartTime: number = 0;
  private voicePauseOffset: number = 0;
  private currentSegmentIndex: number = 0;

  // Audio segments buffer cache
  private segmentBuffers: (AudioBuffer | null)[] = [];
  private segmentDurations: number[] = [];

  // Generative music synthesizer state
  private musicIntervalId: number | null = null;
  private activeMusicOscillators: OscillatorNode[] = [];
  private currentMusicVibe: MusicVibe = 'lofi-chill';
  private backgroundVolume: number = 0.35;
  private isMusicMuted: boolean = false;

  // Playback control and event tracking
  private playbackRate: number = 1.0;
  private onTimeUpdateCallback: ((currentSec: number, totalSec: number) => void) | null = null;
  private onSegmentEndCallback: ((nextSegmentIndex: number) => void) | null = null;
  private onAllEndedCallback: (() => void) | null = null;
  private animationFrameId: number | null = null;

  // Speech synthesis fallback state
  private isSpeechSynthesisActive: boolean = false;
  private currentTurnIndex: number = 0;
  private speechScript: any = null;
  private onTurnChangeCallback: ((turnIndex: number, segIndex: number) => void) | null = null;
  private synthPulseTimer: number | null = null;

  private initContext() {
    if (this.ctx && this.ctx.state !== 'closed') {
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
      return this.ctx;
    }

    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    this.ctx = new AudioContextClass();

    // Broadcast Master Bus
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = 1.0;

    // Master Broadcast Compressor (FM Radio Warmth & Presence)
    this.compressor = this.ctx.createDynamicsCompressor();
    this.compressor.threshold.setValueAtTime(-20, this.ctx.currentTime);
    this.compressor.knee.setValueAtTime(30, this.ctx.currentTime);
    this.compressor.ratio.setValueAtTime(4, this.ctx.currentTime);
    this.compressor.attack.setValueAtTime(0.015, this.ctx.currentTime);
    this.compressor.release.setValueAtTime(0.25, this.ctx.currentTime);

    // Spectrum & VU Analyser
    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 256;
    this.analyser.smoothingTimeConstant = 0.85;

    // Connect Master chain -> Compressor -> Analyser -> Destination
    this.masterGain.connect(this.compressor);
    this.compressor.connect(this.analyser);
    this.analyser.connect(this.ctx.destination);

    // Voice Channel with broadcast presence EQ
    this.voiceGain = this.ctx.createGain();
    this.voiceGain.gain.value = 1.0;

    const vocalHighpass = this.ctx.createBiquadFilter();
    vocalHighpass.type = 'highpass';
    vocalHighpass.frequency.value = 85; // Low-end rumble cut

    const vocalPresence = this.ctx.createBiquadFilter();
    vocalPresence.type = 'peaking';
    vocalPresence.frequency.value = 3200;
    vocalPresence.gain.value = 2.5; // Clear FM radio vocal sheen

    this.voiceGain.connect(vocalHighpass);
    vocalHighpass.connect(vocalPresence);
    vocalPresence.connect(this.masterGain);

    // Music Channel with dynamic Ducking Gain
    this.musicGain = this.ctx.createGain();
    this.musicGain.gain.value = this.backgroundVolume;

    this.duckingGain = this.ctx.createGain();
    this.duckingGain.gain.value = 1.0;

    this.musicGain.connect(this.duckingGain);
    this.duckingGain.connect(this.masterGain);

    return this.ctx;
  }

  public getAnalyser(): AnalyserNode | null {
    if (!this.analyser) {
      this.initContext();
    }
    return this.analyser;
  }

  // Load a base64 WAV segment into an AudioBuffer
  public async loadSegmentAudio(segmentIndex: number, base64Audio: string): Promise<number> {
    const ctx = this.initContext();
    const binaryString = atob(base64Audio);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    const audioBuffer = await ctx.decodeAudioData(bytes.buffer.slice(0));
    this.segmentBuffers[segmentIndex] = audioBuffer;
    this.segmentDurations[segmentIndex] = audioBuffer.duration;
    return audioBuffer.duration;
  }

  public clearSegments() {
    this.stopVoice();
    this.segmentBuffers = [];
    this.segmentDurations = [];
    this.currentSegmentIndex = 0;
    this.voicePauseOffset = 0;
  }

  public getTotalDuration(): number {
    return this.segmentDurations.reduce((sum, dur) => sum + (dur || 0), 0);
  }

  public getCurrentTime(): number {
    let completed = 0;
    for (let i = 0; i < this.currentSegmentIndex; i++) {
      completed += this.segmentDurations[i] || 0;
    }
    if (this.isVoicePlaying && this.ctx) {
      const elapsed = (this.ctx.currentTime - this.voiceStartTime) * this.playbackRate;
      return completed + Math.min(elapsed, this.segmentDurations[this.currentSegmentIndex] || 0);
    }
    return completed + this.voicePauseOffset;
  }

  // Play distinctive 3-tone station jingle / ident
  public playStationIdent(): Promise<void> {
    const ctx = this.initContext();
    return new Promise((resolve) => {
      const now = ctx.currentTime;
      // 3-note chime: F4 (349.23), C5 (523.25), F5 (698.46)
      const freqs = [349.23, 523.25, 698.46];

      freqs.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.16);

        // Add subtle chime harmonic
        const harmonic = ctx.createOscillator();
        const harmGain = ctx.createGain();
        harmonic.type = 'triangle';
        harmonic.frequency.setValueAtTime(freq * 2, now + idx * 0.16);

        const startTime = now + idx * 0.16;
        const endTime = startTime + 0.9;

        gain.gain.setValueAtTime(0.001, startTime);
        gain.gain.exponentialRampToValueAtTime(0.35, startTime + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.0001, endTime);

        harmGain.gain.setValueAtTime(0.001, startTime);
        harmGain.gain.exponentialRampToValueAtTime(0.12, startTime + 0.04);
        harmGain.gain.exponentialRampToValueAtTime(0.0001, endTime);

        osc.connect(gain);
        harmonic.connect(harmGain);
        gain.connect(this.masterGain!);
        harmGain.connect(this.masterGain!);

        osc.start(startTime);
        harmonic.start(startTime);
        osc.stop(endTime);
        harmonic.stop(endTime);
      });

      setTimeout(resolve, 1400);
    });
  }

  // Play a specific segment
  public playSegment(segmentIndex: number, startOffset: number = 0) {
    const ctx = this.initContext();
    const buffer = this.segmentBuffers[segmentIndex];
    if (!buffer) return;

    this.stopVoice();

    this.currentSegmentIndex = segmentIndex;
    this.voicePauseOffset = startOffset;

    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.playbackRate.value = this.playbackRate;
    source.connect(this.voiceGain!);

    this.voiceStartTime = ctx.currentTime - startOffset / this.playbackRate;
    this.currentSource = source;
    this.isVoicePlaying = true;

    // Trigger dynamic sidechain ducking (duck background music to 18%)
    this.setDucking(true);

    source.onended = () => {
      if (this.currentSource === source) {
        this.isVoicePlaying = false;
        this.currentSource = null;
        this.voicePauseOffset = 0;

        // Check if there is another segment ready
        const nextIdx = this.currentSegmentIndex + 1;
        if (nextIdx < this.segmentBuffers.length && this.segmentBuffers[nextIdx]) {
          if (this.onSegmentEndCallback) {
            this.onSegmentEndCallback(nextIdx);
          }
          this.playSegment(nextIdx, 0);
        } else {
          // Finished available segments
          this.setDucking(false);
          if (this.onAllEndedCallback) {
            this.onAllEndedCallback();
          }
        }
      }
    };

    source.start(0, startOffset);
    this.startTracking();
  }

  // Play preview snippet (e.g. voice audition or duo preview) through radio mastering chain
  public async playPreviewAudio(base64Audio: string): Promise<void> {
    const ctx = this.initContext();
    this.stopVoice();

    const binaryString = atob(base64Audio);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    const audioBuffer = await ctx.decodeAudioData(bytes.buffer.slice(0));
    return new Promise((resolve) => {
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.playbackRate.value = this.playbackRate;
      source.connect(this.voiceGain!);

      this.currentSource = source;
      this.isVoicePlaying = true;
      this.setDucking(true);
      this.startTracking();

      source.onended = () => {
        if (this.currentSource === source) {
          this.isVoicePlaying = false;
          this.currentSource = null;
          this.setDucking(false);
          resolve();
        }
      };

      source.start(0);
    });
  }

  // Dual-voice Studio Speech Synthesis (seamless fallback for when API quota is exhausted)
  public startSpeechSynthesisShow(script: any) {
    this.initContext();
    this.speechScript = script;
    this.isSpeechSynthesisActive = true;
    this.currentSegmentIndex = 0;
    this.currentTurnIndex = 0;
    this.isVoicePlaying = true;

    // Estimate durations based on words count if not already set
    if (this.segmentDurations.length === 0) {
      this.segmentDurations = script.segments.map((s: any) => {
        const totalWords = s.turns.reduce((acc: number, t: any) => acc + (t.text ? t.text.split(' ').length : 0), 0);
        return Math.max(30, Math.round(totalWords / 2.5)); // ~150 words per minute
      });
    }

    this.speakTurn(0, 0);
    this.startTracking();
  }

  private speakTurn(segIdx: number, turnIdx: number) {
    if (!this.isSpeechSynthesisActive || !this.speechScript) return;
    if (typeof window === 'undefined' || !window.speechSynthesis) return;

    const segment = this.speechScript.segments[segIdx];
    if (!segment) {
      this.finishAllBroadcast();
      return;
    }

    const turn = segment.turns[turnIdx];
    if (!turn) {
      // Advance to next segment
      const nextSeg = segIdx + 1;
      if (nextSeg < this.speechScript.segments.length) {
        this.currentSegmentIndex = nextSeg;
        this.currentTurnIndex = 0;
        if (this.onSegmentEndCallback) {
          this.onSegmentEndCallback(nextSeg);
        }
        // Small studio breath pause between segments
        setTimeout(() => this.speakTurn(nextSeg, 0), 900);
      } else {
        this.finishAllBroadcast();
      }
      return;
    }

    this.currentSegmentIndex = segIdx;
    this.currentTurnIndex = turnIdx;
    if (this.onTurnChangeCallback) {
      this.onTurnChangeCallback(turnIdx, segIdx);
    }

    // Clean up text tags (strip <laugh>, <breath>, |yeah| -> yeah)
    const cleanedText = turn.text
      .replace(/<[^>]+>/g, '')
      .replace(/\|([^|]+)\|/g, '$1')
      .trim();

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(cleanedText);
    utterance.rate = 1.05 * this.playbackRate;

    // Distinguish Host 1 vs Host 2
    const isHost1 = turn.speaker.toLowerCase().includes(this.speechScript.hosts.host1.name.toLowerCase());
    const voices = window.speechSynthesis.getVoices();

    if (isHost1) {
      utterance.pitch = 0.95; // deeper resonance
      const host1Voice = voices.find(v => (v.name.includes('David') || v.name.includes('Daniel') || v.name.includes('Male') || v.name.includes('Guy')) && v.lang.startsWith('en'));
      if (host1Voice) utterance.voice = host1Voice;
    } else {
      utterance.pitch = 1.14; // brighter, curious cadence
      const host2Voice = voices.find(v => (v.name.includes('Samantha') || v.name.includes('Victoria') || v.name.includes('Karen') || v.name.includes('Female') || v.name.includes('Zira')) && v.lang.startsWith('en'));
      if (host2Voice) utterance.voice = host2Voice;
    }

    utterance.onstart = () => {
      this.isVoicePlaying = true;
      this.setDucking(true);
    };

    utterance.onend = () => {
      // Brief pause between speaker turns
      this.setDucking(false);
      setTimeout(() => {
        if (this.isSpeechSynthesisActive) {
          this.speakTurn(segIdx, turnIdx + 1);
        }
      }, 350);
    };

    utterance.onerror = (e) => {
      if (e.error !== 'canceled') {
        console.warn('SpeechSynthesis turn error:', e.error);
        setTimeout(() => {
          if (this.isSpeechSynthesisActive) {
            this.speakTurn(segIdx, turnIdx + 1);
          }
        }, 300);
      }
    };

    window.speechSynthesis.speak(utterance);
  }

  private finishAllBroadcast() {
    this.isVoicePlaying = false;
    this.isSpeechSynthesisActive = false;
    this.setDucking(false);
    if (this.onAllEndedCallback) {
      this.onAllEndedCallback();
    }
  }

  public pause() {
    if (this.isSpeechSynthesisActive) {
      if (typeof window !== 'undefined' && window.speechSynthesis) {
        window.speechSynthesis.pause();
      }
      this.isVoicePlaying = false;
      this.setDucking(false);
      return;
    }
    if (this.isVoicePlaying && this.ctx) {
      this.voicePauseOffset = (this.ctx.currentTime - this.voiceStartTime) * this.playbackRate;
      this.stopVoice();
      this.setDucking(false);
    }
  }

  public resume() {
    if (this.isSpeechSynthesisActive) {
      if (typeof window !== 'undefined' && window.speechSynthesis) {
        if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
        } else {
          this.speakTurn(this.currentSegmentIndex, this.currentTurnIndex);
        }
      }
      this.isVoicePlaying = true;
      this.setDucking(true);
      return;
    }
    if (!this.isVoicePlaying && this.segmentBuffers[this.currentSegmentIndex]) {
      this.playSegment(this.currentSegmentIndex, this.voicePauseOffset);
    }
  }

  public seek(targetTotalSeconds: number) {
    let accumulated = 0;
    for (let i = 0; i < this.segmentBuffers.length; i++) {
      const dur = this.segmentDurations[i] || 0;
      if (targetTotalSeconds <= accumulated + dur || i === this.segmentBuffers.length - 1) {
        const offsetInSegment = Math.max(0, targetTotalSeconds - accumulated);
        if (this.isVoicePlaying) {
          this.playSegment(i, offsetInSegment);
        } else {
          this.currentSegmentIndex = i;
          this.voicePauseOffset = offsetInSegment;
        }
        break;
      }
      accumulated += dur;
    }
  }

  public setPlaybackRate(rate: number) {
    this.playbackRate = rate;
    if (this.currentSource && this.ctx) {
      this.currentSource.playbackRate.setValueAtTime(rate, this.ctx.currentTime);
    }
  }

  public setMasterVolume(volume: number) {
    this.initContext();
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(Math.max(0, Math.min(1, volume)), this.ctx.currentTime);
    }
  }

  public setBackgroundMusicVolume(volume: number) {
    this.backgroundVolume = Math.max(0, Math.min(1, volume));
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setValueAtTime(this.isMusicMuted ? 0 : this.backgroundVolume, this.ctx.currentTime);
    }
  }

  public toggleMuteMusic(): boolean {
    this.isMusicMuted = !this.isMusicMuted;
    this.setBackgroundMusicVolume(this.backgroundVolume);
    return this.isMusicMuted;
  }

  // Smooth sidechain ducking for broadcast elegance
  private setDucking(isSpeaking: boolean) {
    if (!this.duckingGain || !this.ctx) return;
    const now = this.ctx.currentTime;
    const target = isSpeaking ? 0.16 : 1.0;
    const rampTime = isSpeaking ? 0.12 : 0.45;
    this.duckingGain.gain.cancelScheduledValues(now);
    this.duckingGain.gain.setTargetAtTime(target, now, rampTime);
  }

  // Generative broadcast soundtrack synthesizer
  public startBackgroundMusic(vibe: MusicVibe = 'lofi-chill') {
    this.currentMusicVibe = vibe;
    if (vibe === 'off') {
      this.stopBackgroundMusic();
      return;
    }

    const ctx = this.initContext();
    this.stopBackgroundMusic();

    // Harmonic chord palettes for different radio vibes
    const chordPalettes: Record<string, number[][]> = {
      'lofi-chill': [
        // Ebmaj9, Cm9, Fm9, Bb13
        [155.56, 196.0, 233.08, 293.66, 349.23],
        [130.81, 196.0, 233.08, 311.13, 392.0],
        [174.61, 207.65, 261.63, 311.13, 392.0],
        [116.54, 185.0, 233.08, 277.18, 349.23],
      ],
      'ambient-noir': [
        // F#m9, Dmaj7#11, Bm9, C#m7
        [185.0, 220.0, 277.18, 329.63, 415.3],
        [146.83, 220.0, 277.18, 369.99, 415.3],
        [123.47, 185.0, 220.0, 277.18, 369.99],
        [138.59, 207.65, 277.18, 329.63, 415.3],
      ],
      'tech-minimal': [
        // Clean crystalline modern synth chords
        [220.0, 277.18, 329.63, 440.0],
        [196.0, 246.94, 293.66, 392.0],
        [174.61, 220.0, 261.63, 349.23],
        [164.81, 207.65, 246.94, 329.63],
      ],
      'cinematic-pulse': [
        // Deep cinematic resonant pads
        [110.0, 164.81, 220.0, 329.63],
        [98.0, 146.83, 196.0, 293.66],
        [87.31, 130.81, 174.61, 261.63],
        [82.41, 123.47, 164.81, 246.94],
      ],
      'coffeehouse-acoustic': [
        // Warm jazz-acoustic warmth
        [130.81, 164.81, 196.0, 246.94, 293.66],
        [110.0, 146.83, 174.61, 220.0, 261.63],
        [123.47, 155.56, 185.0, 220.0, 293.66],
        [98.0, 130.81, 164.81, 196.0, 246.94],
      ],
    };

    const palette = chordPalettes[vibe] || chordPalettes['lofi-chill'];
    let chordIdx = 0;

    const playChordStep = () => {
      if (!this.ctx || !this.musicGain) return;
      const now = this.ctx.currentTime;
      const chord = palette[chordIdx % palette.length];
      chordIdx++;

      // Create warm analog filter
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(vibe === 'tech-minimal' ? 2200 : 950, now);
      filter.Q.value = 1.2;
      filter.connect(this.musicGain);

      // Play pad chord notes with gentle envelope
      chord.forEach((freq, noteIdx) => {
        const osc = this.ctx!.createOscillator();
        const noteGain = this.ctx!.createGain();

        osc.type = noteIdx === 0 ? 'triangle' : 'sine';
        // Subtle detune for lush analog warmth
        osc.detune.value = (Math.random() - 0.5) * 8;
        osc.frequency.setValueAtTime(freq, now);

        const chordDuration = 5.6;
        noteGain.gain.setValueAtTime(0.001, now);
        noteGain.gain.exponentialRampToValueAtTime(0.05, now + 1.2);
        noteGain.gain.exponentialRampToValueAtTime(0.035, now + 3.8);
        noteGain.gain.exponentialRampToValueAtTime(0.0001, now + chordDuration);

        osc.connect(noteGain);
        noteGain.connect(filter);

        osc.start(now);
        osc.stop(now + chordDuration);
        this.activeMusicOscillators.push(osc);
      });

      // Subtle pulse or sub tick for groove
      if (vibe === 'lofi-chill' || vibe === 'tech-minimal') {
        const subOsc = this.ctx.createOscillator();
        const subGain = this.ctx.createGain();
        subOsc.type = 'sine';
        subOsc.frequency.setValueAtTime(chord[0] / 2, now);
        subGain.gain.setValueAtTime(0.04, now);
        subGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.8);
        subOsc.connect(subGain);
        subGain.connect(filter);
        subOsc.start(now);
        subOsc.stop(now + 0.8);
      }
    };

    playChordStep();
    this.musicIntervalId = window.setInterval(playChordStep, 5200);
  }

  public stopBackgroundMusic() {
    if (this.musicIntervalId !== null) {
      clearInterval(this.musicIntervalId);
      this.musicIntervalId = null;
    }
    this.activeMusicOscillators.forEach((osc) => {
      try {
        osc.stop();
        osc.disconnect();
      } catch (e) {
        // Ignored
      }
    });
    this.activeMusicOscillators = [];
  }

  private stopVoice() {
    if (this.currentSource) {
      try {
        this.currentSource.stop();
        this.currentSource.disconnect();
      } catch (e) {
        // Ignored
      }
      this.currentSource = null;
    }
    this.isVoicePlaying = false;
  }

  private startTracking() {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }

    const track = () => {
      if (this.onTimeUpdateCallback) {
        this.onTimeUpdateCallback(this.getCurrentTime(), this.getTotalDuration());
      }
      if (this.isVoicePlaying) {
        this.animationFrameId = requestAnimationFrame(track);
      }
    };

    this.animationFrameId = requestAnimationFrame(track);
  }

  public setOnTimeUpdate(cb: (currentSec: number, totalSec: number) => void) {
    this.onTimeUpdateCallback = cb;
  }

  public setOnSegmentEnd(cb: (nextSegmentIndex: number) => void) {
    this.onSegmentEndCallback = cb;
  }

  public setOnAllEnded(cb: () => void) {
    this.onAllEndedCallback = cb;
  }

  public isPlaying(): boolean {
    return this.isVoicePlaying;
  }

  public getCurrentSegmentIndex(): number {
    return this.currentSegmentIndex;
  }

  // Export all loaded audio segments as a single unified WAV Blob
  public exportFullBroadcastWav(): Blob | null {
    const buffers = this.segmentBuffers.filter((b): b is AudioBuffer => b !== null);
    if (buffers.length === 0) return null;

    const sampleRate = buffers[0].sampleRate;
    const numChannels = 1; // mono broadcast
    const totalLength = buffers.reduce((acc, b) => acc + b.length, 0);

    const mergedData = new Float32Array(totalLength);
    let offset = 0;
    for (const b of buffers) {
      const channelData = b.getChannelData(0);
      mergedData.set(channelData, offset);
      offset += b.length;
    }

    // Convert Float32 to 16-bit PCM WAV
    const buffer = new ArrayBuffer(44 + mergedData.length * 2);
    const view = new DataView(buffer);

    // RIFF chunk descriptor
    writeUTFBytes(view, 0, 'RIFF');
    view.setUint32(4, 36 + mergedData.length * 2, true);
    writeUTFBytes(view, 8, 'WAVE');

    // FMT sub-chunk
    writeUTFBytes(view, 12, 'fmt ');
    view.setUint32(16, 16, true); // Subchunk1Size
    view.setUint16(20, 1, true); // AudioFormat 1 = PCM
    view.setUint16(22, numChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * numChannels * 2, true); // byteRate
    view.setUint16(32, numChannels * 2, true); // blockAlign
    view.setUint16(34, 16, true); // bitsPerSample

    // data sub-chunk
    writeUTFBytes(view, 36, 'data');
    view.setUint32(40, mergedData.length * 2, true);

    // Write 16-bit PCM samples
    let index = 44;
    for (let i = 0; i < mergedData.length; i++) {
      const s = Math.max(-1, Math.min(1, mergedData[i]));
      view.setInt16(index, s < 0 ? s * 0x8000 : s * 0x7fff, true);
      index += 2;
    }

    return new Blob([view], { type: 'audio/wav' });
  }
}

function writeUTFBytes(view: DataView, offset: number, string: string) {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

export const broadcastAudioEngine = new BroadcastAudioEngine();
