export interface Turn {
  speaker: string;
  text: string;
  style?: string;
  burst?: string;
}

export interface Segment {
  segmentId: number;
  title: string;
  summary?: string;
  turns: Turn[];
  audioBase64?: string;
  durationSeconds?: number;
  isSynthesizing?: boolean;
}

export interface BroadcastScript {
  showTitle: string;
  stationName: string;
  frequency: string;
  tagline: string;
  targetDurationMinutes: number;
  tone: string;
  musicVibe: string;
  hosts: {
    host1: { name: string; voice: string; persona: string };
    host2: { name: string; voice: string; persona: string };
  };
  segments: Segment[];
  editorialNotes?: string;
}

export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  modifiedTime?: string;
  size?: string;
}

export type MusicVibe = 'lofi-chill' | 'ambient-noir' | 'tech-minimal' | 'cinematic-pulse' | 'coffeehouse-acoustic' | 'off';

export interface HostDuoOption {
  id: string;
  label: string;
  host1Name: string;
  host1Voice: string;
  host2Name: string;
  host2Voice: string;
  vibe: string;
}

export type SynthesisMode = 'low-latency' | 'studio-master';

export interface VoiceProfile {
  id: string;
  name: string;
  gender: 'female' | 'male';
  tone: string;
  description: string;
  accent: string;
  sampleText: string;
}

