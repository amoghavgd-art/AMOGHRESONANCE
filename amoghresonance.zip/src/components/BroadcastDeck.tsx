import React, { useState, useEffect, useRef } from 'react';
import { BroadcastScript, Segment, Turn } from '../types/broadcast';
import { broadcastAudioEngine } from '../lib/audioEngine';
import { AudioVisualizer } from './AudioVisualizer';
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  VolumeX,
  Music,
  Download,
  Copy,
  Check,
  Radio,
  Sliders,
  ChevronDown,
  Sparkles,
  Layers,
  ArrowLeft,
  Users,
} from 'lucide-react';

interface BroadcastDeckProps {
  script: BroadcastScript;
  onReset: () => void;
  onSynthesizeSegmentAgain?: (segmentId: number) => void;
}

export const BroadcastDeck: React.FC<BroadcastDeckProps> = ({
  script,
  onReset,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [totalDuration, setTotalDuration] = useState(0);
  const [currentSegmentIdx, setCurrentSegmentIdx] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1.0);
  const [musicVolume, setMusicVolume] = useState(0.35);
  const [isMusicMuted, setIsMusicMuted] = useState(false);
  const [copiedTranscript, setCopiedTranscript] = useState(false);
  const [isExportingWav, setIsExportingWav] = useState(false);
  const [autoScrollTranscript, setAutoScrollTranscript] = useState(true);

  const transcriptContainerRef = useRef<HTMLDivElement | null>(null);

  // Set up audio engine callbacks
  useEffect(() => {
    broadcastAudioEngine.setOnTimeUpdate((curr, total) => {
      setCurrentTime(curr);
      setTotalDuration(total);
      const activeIdx = broadcastAudioEngine.getCurrentSegmentIndex();
      setCurrentSegmentIdx(activeIdx);
    });

    broadcastAudioEngine.setOnSegmentEnd((nextIdx) => {
      setCurrentSegmentIdx(nextIdx);
    });

    broadcastAudioEngine.setOnAllEnded(() => {
      setIsPlaying(false);
    });

    // Check initial playing state
    setIsPlaying(broadcastAudioEngine.isPlaying());
    setTotalDuration(broadcastAudioEngine.getTotalDuration());

    return () => {
      // Don't kill audio on quick re-renders, but clean up listeners
    };
  }, []);

  // Format seconds to mm:ss
  const formatTime = (seconds: number) => {
    if (isNaN(seconds) || seconds < 0) return '00:00';
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handlePlayPause = async () => {
    if (isPlaying) {
      broadcastAudioEngine.pause();
      setIsPlaying(false);
    } else {
      broadcastAudioEngine.resume();
      setIsPlaying(true);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const target = parseFloat(e.target.value);
    setCurrentTime(target);
    broadcastAudioEngine.seek(target);
  };

  const handleSkip = (seconds: number) => {
    const target = Math.max(0, Math.min(totalDuration, currentTime + seconds));
    setCurrentTime(target);
    broadcastAudioEngine.seek(target);
  };

  const handleSpeedChange = (rate: number) => {
    setPlaybackRate(rate);
    broadcastAudioEngine.setPlaybackRate(rate);
  };

  const handleMusicVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setMusicVolume(val);
    broadcastAudioEngine.setBackgroundMusicVolume(val);
  };

  const handleToggleMuteMusic = () => {
    const muted = broadcastAudioEngine.toggleMuteMusic();
    setIsMusicMuted(muted);
  };

  // Download broadcast audio
  const handleDownloadWav = () => {
    try {
      setIsExportingWav(true);
      const blob = broadcastAudioEngine.exportFullBroadcastWav();
      if (!blob) {
        // If in SpeechSynthesis mode, export the full broadcast screenplay file
        const text = script.segments
          .map(
            (seg) =>
              `[${seg.title}]\n` +
              seg.turns.map((t) => `${t.speaker}: ${t.text}`).join('\n\n')
          )
          .join('\n\n---\n\n');
        const scriptBlob = new Blob(
          [
            `AMOGH RESONANCE 104.7 FM — BROADCAST TRANSCRIPT & SCREENPLAY\n` +
            `Title: ${script.showTitle}\n` +
            `Hosts: ${script.hosts.host1.name} & ${script.hosts.host2.name}\n` +
            `Format: ${script.tone}\n\n` +
            text,
          ],
          { type: 'text/plain' }
        );
        const url = URL.createObjectURL(scriptBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${script.showTitle.replace(/[^a-z0-9]/gi, '_')}_AMOGH_BROADCAST_SCRIPT.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        return;
      }
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${script.showTitle.replace(/[^a-z0-9]/gi, '_')}_AMOGH_RESONANCE.wav`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to export audio:', err);
    } finally {
      setIsExportingWav(false);
    }
  };

  // Copy full transcript to clipboard
  const handleCopyTranscript = () => {
    const text = script.segments
      .map(
        (seg) =>
          `[${seg.title}]\n` +
          seg.turns.map((t) => `${t.speaker}: ${t.text}`).join('\n\n')
      )
      .join('\n\n---\n\n');

    navigator.clipboard.writeText(
      `AMOGH RESONANCE 104.7 FM — BROADCAST TRANSCRIPT\nShow: ${script.showTitle}\nHosts: ${script.hosts.host1.name} & ${script.hosts.host2.name}\n\n${text}`
    );
    setCopiedTranscript(true);
    setTimeout(() => setCopiedTranscript(false), 2000);
  };

  const currentSegment = script.segments[currentSegmentIdx] || script.segments[0];

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 pb-16 animate-in fade-in">
      {/* Top Controls & Navigation */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onReset}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 hover:text-zinc-100 hover:bg-zinc-800 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>New Broadcast</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleCopyTranscript}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 hover:text-zinc-100 transition-colors"
          >
            {copiedTranscript ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-zinc-400" />
                <span>Copy Script</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handleDownloadWav}
            disabled={isExportingWav}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-xs text-amber-300 transition-colors disabled:opacity-50"
            title="Download Full Audio Broadcast (WAV)"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Broadcast WAV</span>
          </button>
        </div>
      </div>

      {/* Main Studio Broadcast Player Console */}
      <div className="rounded-2xl bg-zinc-900/90 border border-zinc-800/90 shadow-2xl overflow-hidden backdrop-blur-xl">
        {/* Station frequency header */}
        <div className="px-6 py-5 border-b border-zinc-800/80 bg-zinc-950/60 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="px-2 py-0.5 rounded-md bg-amber-500 text-zinc-950 text-[11px] font-mono font-bold tracking-wider">
                {script.frequency || '104.7 FM'}
              </span>
              <span className="text-xs uppercase font-mono tracking-widest text-zinc-400">
                {script.stationName || 'AMOGH RESONANCE'}
              </span>
              <span className="text-zinc-600">•</span>
              <span className="text-xs font-mono text-amber-400/90 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                {script.tone}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-zinc-100 mt-2">
              {script.showTitle}
            </h1>
            {script.tagline && (
              <p className="text-xs sm:text-sm text-zinc-400 mt-1 max-w-2xl">
                {script.tagline}
              </p>
            )}
          </div>

          {/* Host Cards */}
          <div className="flex items-center gap-2 self-start md:self-auto">
            <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800">
              <div className="w-7 h-7 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs">
                {script.hosts.host1.name[0]}
              </div>
              <div className="text-left">
                <p className="text-xs font-semibold text-zinc-200">
                  {script.hosts.host1.name}
                </p>
                <p className="text-[10px] text-zinc-500 font-mono">
                  Voice: {script.hosts.host1.voice}
                </p>
              </div>
            </div>

            <span className="text-zinc-600 text-xs font-mono">&</span>

            <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800">
              <div className="w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
                {script.hosts.host2.name[0]}
              </div>
              <div className="text-left">
                <p className="text-xs font-semibold text-zinc-200">
                  {script.hosts.host2.name}
                </p>
                <p className="text-[10px] text-zinc-500 font-mono">
                  Voice: {script.hosts.host2.voice}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Real-time Visualizer */}
        <div className="p-4 sm:p-6 bg-zinc-950/40">
          <AudioVisualizer isPlaying={isPlaying} stationFrequency={script.frequency} />
        </div>

        {/* Playback Controls & Timeline */}
        <div className="px-6 py-5 border-t border-zinc-800/80 bg-zinc-900/60 space-y-4">
          {/* Timeline & Scrubber */}
          <div className="space-y-1.5">
            <div className="relative">
              <input
                type="range"
                min={0}
                max={Math.max(1, totalDuration)}
                step={0.1}
                value={currentTime}
                onChange={handleSeek}
                className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-500 focus:outline-none"
              />
            </div>
            <div className="flex items-center justify-between text-xs font-mono text-zinc-400">
              <span>{formatTime(currentTime)}</span>
              <div className="flex items-center gap-1.5 text-zinc-500 text-[11px]">
                <Layers className="w-3 h-3 text-amber-500" />
                <span>
                  Segment {currentSegmentIdx + 1} of {script.segments.length}:{' '}
                  <span className="text-zinc-300">{currentSegment?.title}</span>
                </span>
              </div>
              <span>{formatTime(totalDuration)}</span>
            </div>
          </div>

          {/* Control Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-1">
            {/* Left: Speed selector */}
            <div className="flex items-center gap-1 bg-zinc-950/60 p-1 rounded-xl border border-zinc-800">
              {[0.8, 1.0, 1.25, 1.5].map((rate) => (
                <button
                  key={rate}
                  type="button"
                  onClick={() => handleSpeedChange(rate)}
                  className={`px-2 py-1 rounded-lg text-[11px] font-mono transition-colors ${
                    playbackRate === rate
                      ? 'bg-amber-500 text-zinc-950 font-bold'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {rate}x
                </button>
              ))}
            </div>

            {/* Center: Main Transport Buttons */}
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => handleSkip(-15)}
                className="p-2.5 rounded-xl bg-zinc-800/80 hover:bg-zinc-800 text-zinc-300 hover:text-zinc-100 transition-colors"
                title="Rewind 15 seconds"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={handlePlayPause}
                className="w-13 h-13 rounded-2xl bg-amber-500 hover:bg-amber-400 text-zinc-950 flex items-center justify-center shadow-lg shadow-amber-500/25 transition-all transform active:scale-95 cursor-pointer font-bold"
              >
                {isPlaying ? (
                  <Pause className="w-6 h-6 fill-current" />
                ) : (
                  <Play className="w-6 h-6 fill-current translate-x-0.5" />
                )}
              </button>

              <button
                type="button"
                onClick={() => handleSkip(15)}
                className="p-2.5 rounded-xl bg-zinc-800/80 hover:bg-zinc-800 text-zinc-300 hover:text-zinc-100 transition-colors"
                title="Forward 15 seconds"
              >
                <RotateCw className="w-4 h-4" />
              </button>
            </div>

            {/* Right: Background Music ducking balance */}
            <div className="flex items-center gap-2 bg-zinc-950/60 px-3 py-1.5 rounded-xl border border-zinc-800">
              <button
                type="button"
                onClick={handleToggleMuteMusic}
                className="text-zinc-400 hover:text-amber-400 transition-colors"
                title={isMusicMuted ? 'Unmute Background Music' : 'Mute Background Music'}
              >
                {isMusicMuted ? (
                  <VolumeX className="w-3.5 h-3.5 text-zinc-600" />
                ) : (
                  <Music className="w-3.5 h-3.5 text-amber-500" />
                )}
              </button>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-mono text-zinc-500">Music</span>
                <input
                  type="range"
                  min={0}
                  max={0.8}
                  step={0.05}
                  value={musicVolume}
                  onChange={handleMusicVolumeChange}
                  className="w-16 h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Live Synchronized Script Teleprompter */}
      <div className="rounded-2xl bg-zinc-900/70 border border-zinc-800/80 p-5 sm:p-6 backdrop-blur-md">
        <div className="flex items-center justify-between pb-4 mb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-amber-500" />
            <h2 className="text-sm font-semibold text-zinc-200">
              Broadcast Teleprompter & Transcript
            </h2>
          </div>
          <div className="flex items-center gap-2 text-xs text-zinc-500">
            <span>Synchronized Dialogue</span>
          </div>
        </div>

        {/* Teleprompter Turns */}
        <div
          ref={transcriptContainerRef}
          className="space-y-4 max-h-[460px] overflow-y-auto pr-2 scrollbar-thin"
        >
          {script.segments.map((segment, segIdx) => {
            const isCurrentSegment = segIdx === currentSegmentIdx;

            return (
              <div
                key={segment.segmentId}
                className={`p-4 rounded-xl border transition-all ${
                  isCurrentSegment
                    ? 'bg-zinc-950/70 border-amber-500/40 shadow-lg shadow-amber-500/5'
                    : 'bg-zinc-950/30 border-zinc-800/60 opacity-70 hover:opacity-100'
                }`}
              >
                {/* Segment Heading */}
                <div className="flex items-center justify-between mb-3 pb-2 border-b border-zinc-800/40">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-zinc-800 text-[10px] font-mono font-semibold text-zinc-300">
                      PART {segIdx + 1}
                    </span>
                    <h3 className="text-xs font-semibold text-zinc-200">
                      {segment.title}
                    </h3>
                  </div>
                  {isCurrentSegment && (
                    <span className="text-[10px] font-mono text-amber-400 font-semibold flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                      ACTIVE
                    </span>
                  )}
                </div>

                {/* Turns */}
                <div className="space-y-3">
                  {segment.turns.map((turn, tIdx) => {
                    const isHost1 = turn.speaker
                      .toLowerCase()
                      .includes(script.hosts.host1.name.toLowerCase());

                    return (
                      <div
                        key={tIdx}
                        className={`flex gap-3 text-xs leading-relaxed ${
                          isHost1 ? 'text-zinc-200' : 'text-zinc-300'
                        }`}
                      >
                        <div className="w-16 sm:w-20 shrink-0">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-semibold tracking-wide ${
                              isHost1
                                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                                : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            }`}
                          >
                            {turn.speaker}
                          </span>
                        </div>
                        <div className="flex-1">
                          <p>
                            {/* Render text with highlighted vocal bursts/backchanneling */}
                            {renderDialogueWithBursts(turn.text)}
                          </p>
                          {turn.style && (
                            <span className="inline-block mt-1 text-[10px] font-mono text-zinc-500 italic">
                              [{turn.style}]
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

// Formats backchanneling (|yeah|, |mhm|) and vocal bursts (<laugh>, <breath>)
function renderDialogueWithBursts(text: string) {
  const parts = text.split(/(\|[^|]+\||<[^>]+>)/g);
  return parts.map((part, i) => {
    if (part.startsWith('|') && part.endsWith('|')) {
      return (
        <span
          key={i}
          className="mx-1 px-1 rounded bg-amber-500/15 text-amber-300 font-mono text-[11px] font-medium"
        >
          {part}
        </span>
      );
    }
    if (part.startsWith('<') && part.endsWith('>')) {
      return (
        <span
          key={i}
          className="mx-1 px-1 rounded bg-zinc-800 text-zinc-400 italic text-[11px]"
        >
          {part}
        </span>
      );
    }
    return part;
  });
}
