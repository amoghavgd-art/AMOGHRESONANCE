import React, { useEffect, useRef, useState } from 'react';
import { broadcastAudioEngine } from '../lib/audioEngine';
import { Activity, Radio, BarChart3 } from 'lucide-react';

interface AudioVisualizerProps {
  isPlaying: boolean;
  stationFrequency?: string;
}

export const AudioVisualizer: React.FC<AudioVisualizerProps> = ({
  isPlaying,
  stationFrequency = '104.7 FM',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [visualMode, setVisualMode] = useState<'spectrum' | 'wave' | 'vu'>('spectrum');

  useEffect(() => {
    let animationFrameId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const analyser = broadcastAudioEngine.getAnalyser();

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      // Background subtle studio grid
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
      ctx.lineWidth = 1;
      const gridSize = 16;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      if (!analyser || !isPlaying) {
        // Idle ambient breathing line
        ctx.beginPath();
        ctx.moveTo(0, height / 2);
        const time = Date.now() * 0.002;
        for (let x = 0; x < width; x++) {
          const y = height / 2 + Math.sin(x * 0.03 + time) * 2;
          ctx.lineTo(x, y);
        }
        ctx.strokeStyle = 'rgba(217, 119, 6, 0.35)'; // Amber phosphor idle
        ctx.lineWidth = 1.5;
        ctx.stroke();

        animationFrameId = requestAnimationFrame(render);
        return;
      }

      if (visualMode === 'spectrum') {
        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        analyser.getByteFrequencyData(dataArray);

        const barCount = 48;
        const step = Math.floor(bufferLength / barCount);
        const barWidth = width / barCount - 2;

        for (let i = 0; i < barCount; i++) {
          let sum = 0;
          for (let j = 0; j < step; j++) {
            sum += dataArray[i * step + j] || 0;
          }
          const val = sum / step;
          const barHeight = (val / 255) * (height - 8);

          const x = i * (barWidth + 2);
          const y = height - barHeight;

          // Studio amber-to-copper gradient
          const gradient = ctx.createLinearGradient(0, height, 0, 0);
          gradient.addColorStop(0, 'rgba(180, 83, 9, 0.4)');
          gradient.addColorStop(0.7, 'rgba(245, 158, 11, 0.85)');
          gradient.addColorStop(1, 'rgba(254, 243, 199, 1)');

          ctx.fillStyle = gradient;
          ctx.fillRect(x, y, barWidth, barHeight);

          // Peak cap
          if (barHeight > 4) {
            ctx.fillStyle = '#fef3c7';
            ctx.fillRect(x, Math.max(0, y - 2), barWidth, 1.5);
          }
        }
      } else if (visualMode === 'wave') {
        const bufferLength = analyser.fftSize;
        const dataArray = new Uint8Array(bufferLength);
        analyser.getByteTimeDomainData(dataArray);

        ctx.lineWidth = 2;
        ctx.strokeStyle = '#f59e0b';
        ctx.shadowColor = '#f59e0b';
        ctx.shadowBlur = 6;
        ctx.beginPath();

        const sliceWidth = width / bufferLength;
        let x = 0;

        for (let i = 0; i < bufferLength; i++) {
          const v = dataArray[i] / 128.0;
          const y = (v * height) / 2;

          if (i === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
          x += sliceWidth;
        }

        ctx.lineTo(width, height / 2);
        ctx.stroke();
        ctx.shadowBlur = 0;
      } else if (visualMode === 'vu') {
        // Dual Stereo VU Meters
        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        analyser.getByteFrequencyData(dataArray);

        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        const avg = sum / bufferLength;
        const level = Math.min(1, avg / 140);

        const meterHeight = 12;
        const meterY1 = height / 2 - 16;
        const meterY2 = height / 2 + 6;
        const meterWidth = width - 80;

        // Channel L
        renderVuBar(ctx, 40, meterY1, meterWidth, meterHeight, level, 'CH-1');
        // Channel R (with slight random analog stereo divergence)
        const levelR = Math.min(1, level * (0.92 + Math.random() * 0.15));
        renderVuBar(ctx, 40, meterY2, meterWidth, meterHeight, levelR, 'CH-2');
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isPlaying, visualMode]);

  return (
    <div className="relative w-full rounded-xl bg-zinc-950/90 border border-zinc-800/80 p-3 sm:p-4 backdrop-blur-md overflow-hidden shadow-2xl">
      {/* Top Console Bar */}
      <div className="flex items-center justify-between pb-2 mb-2 border-b border-zinc-800/50 text-xs">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800">
            <Radio className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
            <span className="font-mono text-zinc-300 font-medium tracking-wide">
              {stationFrequency}
            </span>
          </div>
          <div className="hidden sm:flex items-center gap-1.5 text-zinc-400 font-mono">
            <span>•</span>
            <span>24.0 kHz RIFF MONO/STEREO</span>
          </div>
        </div>

        {/* Visualizer Mode Selectors */}
        <div className="flex items-center gap-1 bg-zinc-900/80 p-0.5 rounded-lg border border-zinc-800">
          <button
            type="button"
            onClick={() => setVisualMode('spectrum')}
            className={`p-1 rounded text-xs transition-colors ${
              visualMode === 'spectrum'
                ? 'bg-amber-500/20 text-amber-400 font-medium'
                : 'text-zinc-500 hover:text-zinc-300'
            }`}
            title="Frequency Spectrum"
          >
            <BarChart3 className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setVisualMode('wave')}
            className={`p-1 rounded text-xs transition-colors ${
              visualMode === 'wave'
                ? 'bg-amber-500/20 text-amber-400 font-medium'
                : 'text-zinc-500 hover:text-zinc-300'
            }`}
            title="Oscilloscope Waveform"
          >
            <Activity className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setVisualMode('vu')}
            className={`px-1.5 py-0.5 rounded text-[11px] font-mono transition-colors ${
              visualMode === 'vu'
                ? 'bg-amber-500/20 text-amber-400 font-medium'
                : 'text-zinc-500 hover:text-zinc-300'
            }`}
            title="Stereo VU Meter"
          >
            VU
          </button>
        </div>
      </div>

      {/* Canvas */}
      <canvas
        ref={canvasRef}
        width={640}
        height={96}
        className="w-full h-24 block rounded-lg bg-zinc-950/70"
      />

      {/* Live On-Air Pill */}
      <div className="absolute bottom-3 right-4 flex items-center gap-1.5 pointer-events-none">
        <span
          className={`w-2 h-2 rounded-full ${
            isPlaying ? 'bg-red-500 animate-ping' : 'bg-zinc-700'
          }`}
        />
        <span
          className={`text-[10px] font-mono font-semibold tracking-wider ${
            isPlaying ? 'text-red-400' : 'text-zinc-600'
          }`}
        >
          {isPlaying ? 'ON AIR' : 'STANDBY'}
        </span>
      </div>
    </div>
  );
};

function renderVuBar(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  level: number,
  label: string
) {
  // Label
  ctx.fillStyle = '#71717a';
  ctx.font = '10px monospace';
  ctx.fillText(label, x - 32, y + height - 2);

  // Background trough
  ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
  ctx.fillRect(x, y, width, height);

  // Filled meter
  const fillWidth = Math.max(0, Math.min(width, width * level));
  const grad = ctx.createLinearGradient(x, 0, x + width, 0);
  grad.addColorStop(0, '#10b981'); // Green normal
  grad.addColorStop(0.7, '#f59e0b'); // Amber warning
  grad.addColorStop(0.9, '#ef4444'); // Red peak

  ctx.fillStyle = grad;
  ctx.fillRect(x, y, fillWidth, height);

  // Segment dividers
  ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
  const segStep = 8;
  for (let s = x; s < x + width; s += segStep) {
    ctx.fillRect(s, y, 1, height);
  }
}
