import React from 'react';
import { BroadcastScript } from '../types/broadcast';
import { Radio, Play, Sparkles, Clock } from 'lucide-react';

interface CuratedBroadcastsProps {
  onSelectBroadcast: (script: BroadcastScript) => void;
  disabled?: boolean;
}

export const PREMIER_SHOWS: BroadcastScript[] = [
  {
    showTitle: 'The Fermi Silence: Why We Haven’t Found Anyone',
    stationName: 'AMOGH RESONANCE',
    frequency: '104.7 FM',
    tagline: 'A late-night cosmic deep dive into Dyson spheres, the Great Filter, and cosmic loneliness.',
    targetDurationMinutes: 5,
    tone: 'Conversational Deep Dive (NotebookLM style)',
    musicVibe: 'ambient-noir',
    hosts: {
      host1: { name: 'Devon', voice: 'Zephyr', persona: 'Thoughtful, analytical astronomer' },
      host2: { name: 'Maya', voice: 'Kore', persona: 'Curious, sharp co-host asking the hard questions' },
    },
    editorialNotes: 'Premier archive feature on astronomy and existential probability.',
    segments: [
      {
        segmentId: 1,
        title: 'The Paradox of Trillions',
        summary: 'Setting up the sheer scale of the observable cosmos.',
        turns: [
          {
            speaker: 'Devon',
            text: 'Welcome back to AMOGH RESONANCE, broadcasting on 104.7 FM. <breath> You know Maya, when you look up at night and think about the sheer math... two trillion galaxies, each with hundreds of billions of stars... the silence feels almost loud.',
            style: 'Intimate, warm late-night broadcaster',
          },
          {
            speaker: 'Maya',
            text: 'It really is! |yeah| Because statistically, even if life is a one-in-a-billion fluke, the cosmos should be crawling with signals by now. So where is everyone?',
            style: 'Curious, energetic co-host',
          },
          {
            speaker: 'Devon',
            text: 'Right! That was Enrico Fermi\'s famous lunch table question in 1950. But the modern twist is even spookier: Robin Hanson\'s "Great Filter" hypothesis. Either we\'ve already survived an impossible evolutionary bottleneck... or it\'s waiting right in front of us.',
            style: 'Deep, engaging analytical breakdown',
          },
          {
            speaker: 'Maya',
            text: 'Wait, <laugh> so finding microbes on Mars might actually be terrifying news, not exciting news?',
            style: 'Surprised, witty realization',
          },
        ],
      },
      {
        segmentId: 2,
        title: 'The Dark Forest & The Filter',
        summary: 'Exploring why civilizations might choose deliberate radio silence.',
        turns: [
          {
            speaker: 'Devon',
            text: 'Exactly! If life emerges easily, then the wall that wipes civilizations out must be ahead of us—like runaway artificial intelligence or planetary climate collapse. |mhm|',
            style: 'Thoughtful radio host',
          },
          {
            speaker: 'Maya',
            text: 'Or, as Cixin Liu argued in The Dark Forest: maybe everyone is out there, but they are all deliberately staying quiet because the universe is a dark forest where making noise invites predators.',
            style: 'Intrigued, atmospheric delivery',
          },
          {
            speaker: 'Devon',
            text: 'And here we are on Earth, shouting into the radio spectrum for the last eighty years! <chuckle> But whether we are the first, the survivors, or just early to the party... this quiet cosmic hour on 104.7 FM reminds us how precious this pale blue dot really is.',
            style: 'Reflective sign-off with warmth',
          },
          {
            speaker: 'Maya',
            text: 'Couldn\'t agree more Devon. Keep your receivers tuned to AMOGH RESONANCE.',
            style: 'Smooth outro closing',
          },
        ],
      },
    ],
  },
  {
    showTitle: 'The Architecture of Human Sleep & The Dreaming Mind',
    stationName: 'AMOGH RESONANCE',
    frequency: '104.7 FM',
    tagline: 'Why evolution paralyzes our bodies every night to defragment our memories.',
    targetDurationMinutes: 5,
    tone: 'Late-Night Introspective Radio',
    musicVibe: 'lofi-chill',
    hosts: {
      host1: { name: 'Kieran', voice: 'Charon', persona: 'Late-night baritone host' },
      host2: { name: 'Mara', voice: 'Fenrir', persona: 'Neuroscience investigator with dry wit' },
    },
    editorialNotes: 'Neurobiology of slow-wave sleep and memory consolidation.',
    segments: [
      {
        segmentId: 1,
        title: 'The Biological Mystery',
        summary: 'Why sleep seems biologically absurd on paper.',
        turns: [
          {
            speaker: 'Kieran',
            text: 'You are tuned into AMOGH RESONANCE 104.7 FM. If you\'re listening to this in the dead of night, you are actively resisting the single most bizarre evolutionary trade-off on Earth.',
            style: 'Low, velvety late-night baritone',
          },
          {
            speaker: 'Mara',
            text: 'Seriously. Think about it from a predator standpoint: you lay unconscious for eight hours, totally defenseless. If sleep didn\'t serve an absolute mission-critical purpose, natural selection would have deleted it millions of years ago.',
            style: 'Sharp, articulate scientific co-host',
          },
          {
            speaker: 'Kieran',
            text: 'Yet every creature with a central nervous system does it. And the revelation of the last decade is the glymphatic system—our brain\'s nocturnal sewage system.',
            style: 'Captivating storytelling',
          },
          {
            speaker: 'Mara',
            text: '|yeah| During deep slow-wave sleep, your brain cells literally shrink by sixty percent, allowing cerebrospinal fluid to wash through and flush metabolic waste like beta-amyloid.',
            style: 'Enthusiastic fact breakdown',
          },
        ],
      },
      {
        segmentId: 2,
        title: 'REM and Creative Synthesis',
        summary: 'How dreams connect remote memories into new ideas.',
        turns: [
          {
            speaker: 'Kieran',
            text: 'It\'s literally a physical power-wash for your thoughts. And then you hit REM sleep, where the brain becomes hyper-associative.',
            style: 'Smooth radio pacing',
          },
          {
            speaker: 'Mara',
            text: 'That\'s when the weird stuff happens! <laugh> Dreams aren\'t just random noise—they\'re an offline theater where your hippocampus tests bizarre combinations of memories to build novel intuitions for tomorrow.',
            style: 'Playful yet profound',
          },
          {
            speaker: 'Kieran',
            text: 'So if you\'re working on a hard problem tonight, the best engineering decision might just be closing your eyes. Stay tuned to AMOGH RESONANCE, the night shift continues.',
            style: 'Warm, reassuring sign-off',
          },
        ],
      },
    ],
  },
];

export const CuratedBroadcasts: React.FC<CuratedBroadcastsProps> = ({
  onSelectBroadcast,
  disabled = false,
}) => {
  return (
    <div className="w-full max-w-4xl mx-auto space-y-4 pt-4 border-t border-zinc-800/60">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs font-mono text-zinc-400">
          <Radio className="w-4 h-4 text-amber-500" />
          <span className="uppercase tracking-wider font-semibold text-zinc-300">
            AMOGH Archive Station Presets
          </span>
        </div>
        <span className="text-[11px] text-zinc-500 font-mono">Instant Preview</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {PREMIER_SHOWS.map((show, idx) => (
          <div
            key={idx}
            className="rounded-xl p-4 bg-zinc-900/60 border border-zinc-800/80 hover:border-zinc-700 hover:bg-zinc-800/40 transition-all flex flex-col justify-between gap-3 group"
          >
            <div>
              <div className="flex items-center justify-between text-[11px] font-mono text-zinc-500 pb-1">
                <span className="text-amber-400/90 font-medium">104.7 FM STEREO</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {show.targetDurationMinutes} min
                </span>
              </div>
              <h3 className="text-sm font-bold text-zinc-200 group-hover:text-amber-400 transition-colors">
                {show.showTitle}
              </h3>
              <p className="text-xs text-zinc-400 mt-1 line-clamp-2">{show.tagline}</p>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-zinc-800/60">
              <span className="text-[11px] text-zinc-500 font-mono">
                {show.hosts.host1.name} & {show.hosts.host2.name}
              </span>
              <button
                type="button"
                disabled={disabled}
                onClick={() => onSelectBroadcast(show)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 group-hover:bg-amber-500 text-zinc-300 group-hover:text-zinc-950 text-xs font-semibold transition-all disabled:opacity-50"
              >
                <Play className="w-3 h-3 fill-current" />
                <span>Tune In</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
