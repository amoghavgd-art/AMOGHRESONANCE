import React, { useState } from 'react';
import { MusicVibe, HostDuoOption, SynthesisMode, VoiceProfile } from '../types/broadcast';
import { broadcastAudioEngine } from '../lib/audioEngine';
import {
  Sparkles,
  Clock,
  Users,
  Music,
  Radio,
  FileText,
  HardDrive,
  Loader2,
  ChevronRight,
  Play,
  Square,
  Volume2,
  Zap,
  Sliders,
  CheckCircle2,
  Mic,
  Settings2,
} from 'lucide-react';

interface BroadcastStudioInputProps {
  onGenerate: (params: {
    topic: string;
    targetDurationMinutes: number;
    tone: string;
    hostDuo: string;
    musicVibe: MusicVibe;
    synthesisMode: SynthesisMode;
    customHost1?: { name: string; voice: string };
    customHost2?: { name: string; voice: string };
  }) => void;
  isGenerating: boolean;
  generationStep: string;
  onOpenDriveModal?: () => void;
  hasDriveAccess: boolean;
  importedDocTitle?: string | null;
  importedText?: string | null;
}

const HOST_DUOS: HostDuoOption[] = [
  {
    id: 'devon-maya',
    label: 'Devon & Maya',
    host1Name: 'Devon',
    host1Voice: 'Zephyr',
    host2Name: 'Maya',
    host2Voice: 'Kore',
    vibe: 'Analytical Deep Thinkers (NotebookLM style)',
  },
  {
    id: 'midnight-noir',
    label: 'Kieran & Mara',
    host1Name: 'Kieran',
    host1Voice: 'Charon',
    host2Name: 'Mara',
    host2Voice: 'Fenrir',
    vibe: 'Late-Night Introspective Noir & Rich Baritone',
  },
  {
    id: 'electric-banter',
    label: 'Alex & Elena',
    host1Name: 'Alex',
    host1Voice: 'Puck',
    host2Name: 'Elena',
    host2Voice: 'Kore',
    vibe: 'High-Energy Banter & Fast-Paced Curiosity',
  },
];

export const VOICE_PROFILES: VoiceProfile[] = [
  {
    id: 'Zephyr',
    name: 'Devon',
    gender: 'male',
    tone: 'Smooth & Analytical',
    accent: 'Neutral Modern',
    description: 'Calm, thoughtful, natural cadence with deep intellect',
    sampleText: "Welcome to AMOGH RESONANCE on 104.7 FM. I'm Devon, analyzing the deepest patterns of reality.",
  },
  {
    id: 'Kore',
    name: 'Maya',
    gender: 'female',
    tone: 'Warm & Articulate',
    accent: 'Expressive Studio',
    description: 'Empathetic, clear, penetrating curiosity and bright wit',
    sampleText: "Hey there! Maya here on 104.7 FM. Let's dig beneath the surface and uncover what really matters.",
  },
  {
    id: 'Puck',
    name: 'Alex',
    gender: 'male',
    tone: 'Spirited & Charismatic',
    accent: 'Brisk British',
    description: 'Fast-paced, vibrant, spontaneous energy and quick humor',
    sampleText: "Brilliant to have you with us! Alex here on AMOGH RESONANCE, ready for some high-velocity exploration.",
  },
  {
    id: 'Charon',
    name: 'Kieran',
    gender: 'male',
    tone: 'Late-Night Velvet Baritone',
    accent: 'Deep Resonant',
    description: 'Intimate, warm, smoky late-night FM presence',
    sampleText: "Midnight on 104.7 FM. This is Kieran. Settle in, let the static fade, and listen closely.",
  },
  {
    id: 'Fenrir',
    name: 'Mara',
    gender: 'female',
    tone: 'Intellectual & Sharp',
    accent: 'Dry Gravitas',
    description: 'Astute investigator with wry humor and razor focus',
    sampleText: "Mara on AMOGH RESONANCE. Questioning assumptions, dissecting paradoxes, and following the evidence.",
  },
];

const INSPIRATION_PROMPTS = [
  'The Fermi Paradox: Why is the cosmos so eerily silent despite trillions of stars?',
  'The Psychology of Flow State: Why modern notification culture destroys deep work',
  'The Late Bronze Age Collapse: When ancient civilizations vanished overnight',
  'How Neural Networks Actually Think: An intuitive mental model without math jargon',
  'The Strange Physics of Tape Saturation and why human ears crave analog warmth',
  'Urban Solitude and the art of walking in Tokyo at 3:00 AM',
];

export const BroadcastStudioInput: React.FC<BroadcastStudioInputProps> = ({
  onGenerate,
  isGenerating,
  generationStep,
  onOpenDriveModal,
  hasDriveAccess,
  importedDocTitle,
  importedText,
}) => {
  const [topic, setTopic] = useState('');
  const [duration, setDuration] = useState<number>(5);
  const [hostDuo, setHostDuo] = useState<string>('devon-maya');
  const [tone, setTone] = useState<string>('Conversational Deep Dive (NotebookLM style)');
  const [musicVibe, setMusicVibe] = useState<MusicVibe>('lofi-chill');
  const [synthesisMode, setSynthesisMode] = useState<SynthesisMode>('low-latency');

  // Custom Duo States
  const [isCustomDuo, setIsCustomDuo] = useState(false);
  const [customHost1Name, setCustomHost1Name] = useState('Devon');
  const [customHost1Voice, setCustomHost1Voice] = useState('Zephyr');
  const [customHost2Name, setCustomHost2Name] = useState('Maya');
  const [customHost2Voice, setCustomHost2Voice] = useState('Kore');

  // Voice audition playback state
  const [auditioningVoice, setAuditioningVoice] = useState<string | null>(null);
  const [auditioningDuo, setAuditioningDuo] = useState<string | null>(null);
  const [auditionError, setAuditionError] = useState<string | null>(null);

  React.useEffect(() => {
    if (importedText) {
      setTopic(importedText);
    }
  }, [importedText]);

  // Audition an individual voice
  const handleAuditionVoice = async (voiceProfile: VoiceProfile) => {
    try {
      if (auditioningVoice === voiceProfile.id) {
        broadcastAudioEngine.pause();
        setAuditioningVoice(null);
        return;
      }

      setAuditioningVoice(voiceProfile.id);
      setAuditionError(null);

      const res = await fetch('/api/broadcast/preview-voice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          voice: voiceProfile.id,
          text: voiceProfile.sampleText,
        }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || 'Voice preview failed');
      }

      const data = await res.json();
      if (data.audioBase64) {
        await broadcastAudioEngine.playPreviewAudio(data.audioBase64);
      }
      setAuditioningVoice(null);
    } catch (err: any) {
      console.warn('Audition error:', err);
      setAuditionError(`Could not preview ${voiceProfile.id}: ${err.message}`);
      setAuditioningVoice(null);
    }
  };

  // Audition a host duo banter snippet
  const handleAuditionDuo = async (e: React.MouseEvent, duo: HostDuoOption) => {
    e.stopPropagation();
    try {
      if (auditioningDuo === duo.id) {
        broadcastAudioEngine.pause();
        setAuditioningDuo(null);
        return;
      }

      setAuditioningDuo(duo.id);
      setAuditionError(null);

      const res = await fetch('/api/broadcast/preview-duo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          host1Name: duo.host1Name,
          host1Voice: duo.host1Voice,
          host2Name: duo.host2Name,
          host2Voice: duo.host2Voice,
        }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || 'Duo preview failed');
      }

      const data = await res.json();
      if (data.audioBase64) {
        await broadcastAudioEngine.playPreviewAudio(data.audioBase64);
      }
      setAuditioningDuo(null);
    } catch (err: any) {
      console.warn('Duo audition error:', err);
      setAuditionError(`Could not preview duo: ${err.message}`);
      setAuditioningDuo(null);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim() || isGenerating) return;

    onGenerate({
      topic: topic.trim(),
      targetDurationMinutes: duration,
      tone,
      hostDuo: isCustomDuo ? 'custom-duo' : hostDuo,
      musicVibe,
      synthesisMode,
      customHost1: isCustomDuo ? { name: customHost1Name, voice: customHost1Voice } : undefined,
      customHost2: isCustomDuo ? { name: customHost2Name, voice: customHost2Voice } : undefined,
    });
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Studio Header */}
      <div className="text-center space-y-2 pt-2">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-mono font-medium">
          <Radio className="w-3.5 h-3.5 animate-pulse" />
          <span>AMOGH RESONANCE • 104.7 FM NEURAL TRANSMITTER</span>
        </div>
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-zinc-100">
          Synthesize A Real Radio Show
        </h1>
        <p className="text-sm sm:text-base text-zinc-400 max-w-2xl mx-auto leading-relaxed">
          Type any thought, paste notes, or import Google Docs. Two neural hosts broadcast an ultra-realistic
          NotebookLM-style dialogue with witty banter, vocal bursts, and dynamic background music ducking.
        </p>

        {/* Real API Status Banner */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[11px] font-mono">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>Real Gemini 3.8 Neural Audio Engine Active • Low-Latency 24kHz Stereo Ready</span>
        </div>
      </div>

      {/* Interactive Neural Voice Audition Soundboard */}
      <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800/80 p-4 sm:p-5 backdrop-blur-md space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Mic className="w-4 h-4 text-amber-500" />
            <h2 className="text-xs font-semibold text-zinc-200 uppercase tracking-wider font-mono">
              Realistic Voice Audition Soundboard
            </h2>
          </div>
          <span className="text-[10px] text-zinc-500 font-mono">
            Click to audition authentic Gemini neural voices
          </span>
        </div>

        {auditionError && (
          <div className="p-2.5 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center justify-between">
            <span>{auditionError}</span>
            <button
              type="button"
              onClick={() => setAuditionError(null)}
              className="text-rose-400 hover:text-rose-200 text-[11px]"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* 5 Authentic Voices Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-2.5">
          {VOICE_PROFILES.map((vp) => {
            const isPlayingThis = auditioningVoice === vp.id;
            return (
              <div
                key={vp.id}
                className={`p-3 rounded-xl border transition-all flex flex-col justify-between gap-2 text-left relative overflow-hidden ${
                  isPlayingThis
                    ? 'bg-amber-500/15 border-amber-500/60 shadow-lg shadow-amber-500/10'
                    : 'bg-zinc-950/50 border-zinc-800/80 hover:border-zinc-700 hover:bg-zinc-900/80'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between pb-1">
                    <span className="text-xs font-bold text-zinc-200">{vp.name}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-zinc-800 text-amber-400 font-semibold">
                      {vp.id}
                    </span>
                  </div>
                  <p className="text-[10px] text-amber-400/90 font-medium">{vp.tone}</p>
                  <p className="text-[10px] text-zinc-500 mt-0.5 line-clamp-2 leading-snug">
                    {vp.description}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => handleAuditionVoice(vp)}
                  className={`w-full py-1.5 px-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    isPlayingThis
                      ? 'bg-amber-500 text-zinc-950 shadow-md'
                      : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200'
                  }`}
                >
                  {isPlayingThis ? (
                    <>
                      <Square className="w-3 h-3 fill-current" />
                      <span>Playing...</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-3 h-3 text-amber-400" />
                      <span>Audition</span>
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Input Form */}
      <form
        onSubmit={handleSubmit}
        className="rounded-2xl bg-zinc-900/80 border border-zinc-800/90 shadow-2xl p-5 sm:p-7 backdrop-blur-xl space-y-6"
      >
        {/* Topic Input Area */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <label className="font-semibold text-zinc-200 flex items-center gap-1.5">
              <span>Broadcast Topic, Notes, or Research</span>
            </label>

            {onOpenDriveModal && (
              <button
                type="button"
                onClick={onOpenDriveModal}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-800/80 hover:bg-zinc-800 text-zinc-300 hover:text-amber-400 border border-zinc-700/60 transition-colors"
              >
                <HardDrive className="w-3.5 h-3.5 text-amber-400" />
                <span>{hasDriveAccess ? 'Import Google Doc' : 'Connect Google Drive'}</span>
              </button>
            )}
          </div>

          {importedDocTitle && (
            <div className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
              <span className="flex items-center gap-1.5 truncate">
                <FileText className="w-3.5 h-3.5" />
                <span>Loaded from: <strong>{importedDocTitle}</strong></span>
              </span>
              <button
                type="button"
                onClick={() => setTopic('')}
                className="text-amber-400 hover:text-amber-200 text-[11px]"
              >
                Clear
              </button>
            </div>
          )}

          <div className="relative">
            <textarea
              rows={4}
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="What do you want the hosts to talk about? (e.g. 'Why time feels like it moves faster as we age', or paste an entire paper, outline, or thought...)"
              className="w-full bg-zinc-950/70 border border-zinc-800/90 rounded-xl p-4 text-sm text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/40 resize-y min-h-[110px]"
              disabled={isGenerating}
            />
          </div>

          {/* Inspiration Chips */}
          <div className="space-y-1.5 pt-1">
            <div className="flex items-center gap-1.5 text-[11px] text-zinc-500 font-mono">
              <Sparkles className="w-3 h-3 text-amber-500" />
              <span>Quick inspiration prompts:</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {INSPIRATION_PROMPTS.map((prompt, idx) => (
                <button
                  key={idx}
                  type="button"
                  disabled={isGenerating}
                  onClick={() => setTopic(prompt)}
                  className="text-left text-[11px] px-2.5 py-1 rounded-lg bg-zinc-950/50 hover:bg-zinc-800 border border-zinc-800/80 text-zinc-400 hover:text-zinc-200 transition-colors truncate max-w-xs sm:max-w-none"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Configuration Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 border-t border-zinc-800/60">
          {/* 1. Target Duration */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-amber-500" />
              <span>Broadcast Length</span>
            </label>
            <div className="grid grid-cols-3 gap-1.5 bg-zinc-950/60 p-1 rounded-xl border border-zinc-800">
              {[3, 5, 8, 12, 15].map((mins) => (
                <button
                  key={mins}
                  type="button"
                  disabled={isGenerating}
                  onClick={() => setDuration(mins)}
                  className={`py-1.5 px-2 rounded-lg text-xs font-mono font-medium transition-colors ${
                    duration === mins
                      ? 'bg-amber-500 text-zinc-950 font-bold'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
                  }`}
                >
                  {mins} min
                </button>
              ))}
            </div>
            <p className="text-[10px] text-zinc-500 font-mono">
              {duration <= 3
                ? 'Flash Briefing (2 segments)'
                : duration <= 6
                ? 'Deep Feature (3 segments)'
                : duration <= 10
                ? 'Extended Special (4 segments)'
                : 'Full Masterclass (5 segments)'}
            </p>
          </div>

          {/* 2. Host Duo */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <label className="font-semibold text-zinc-300 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-amber-500" />
                <span>Broadcast Voice Duo</span>
              </label>
              <button
                type="button"
                onClick={() => setIsCustomDuo(!isCustomDuo)}
                className="text-[11px] text-amber-400 hover:text-amber-300 transition-colors"
              >
                {isCustomDuo ? 'Use Presets' : 'Custom Duo'}
              </button>
            </div>

            {isCustomDuo ? (
              <div className="p-2.5 rounded-xl bg-zinc-950/60 border border-amber-500/40 space-y-2 text-xs">
                <div>
                  <label className="text-[10px] text-zinc-400 font-mono block">Host 1</label>
                  <div className="flex gap-1.5 mt-0.5">
                    <input
                      type="text"
                      value={customHost1Name}
                      onChange={(e) => setCustomHost1Name(e.target.value)}
                      className="w-1/2 bg-zinc-900 border border-zinc-800 rounded px-2 py-1 text-xs text-zinc-200"
                      placeholder="Name"
                    />
                    <select
                      value={customHost1Voice}
                      onChange={(e) => setCustomHost1Voice(e.target.value)}
                      className="w-1/2 bg-zinc-900 border border-zinc-800 rounded px-2 py-1 text-xs text-zinc-200"
                    >
                      {VOICE_PROFILES.map((v) => (
                        <option key={v.id} value={v.id}>
                          {v.id} ({v.name})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-[10px] text-zinc-400 font-mono block">Host 2</label>
                  <div className="flex gap-1.5 mt-0.5">
                    <input
                      type="text"
                      value={customHost2Name}
                      onChange={(e) => setCustomHost2Name(e.target.value)}
                      className="w-1/2 bg-zinc-900 border border-zinc-800 rounded px-2 py-1 text-xs text-zinc-200"
                      placeholder="Name"
                    />
                    <select
                      value={customHost2Voice}
                      onChange={(e) => setCustomHost2Voice(e.target.value)}
                      className="w-1/2 bg-zinc-900 border border-zinc-800 rounded px-2 py-1 text-xs text-zinc-200"
                    >
                      {VOICE_PROFILES.map((v) => (
                        <option key={v.id} value={v.id}>
                          {v.id} ({v.name})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-1.5">
                {HOST_DUOS.map((duo) => {
                  const isAuditioning = auditioningDuo === duo.id;
                  return (
                    <div
                      key={duo.id}
                      onClick={() => setHostDuo(duo.id)}
                      className={`w-full text-left p-2 rounded-xl border text-xs transition-all flex items-center justify-between cursor-pointer ${
                        hostDuo === duo.id
                          ? 'bg-amber-500/10 border-amber-500/50 text-amber-300'
                          : 'bg-zinc-950/40 border-zinc-800/80 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
                      }`}
                    >
                      <div className="min-w-0 pr-1">
                        <p className="font-semibold text-zinc-200">{duo.label}</p>
                        <p className="text-[10px] text-zinc-500 truncate max-w-[150px]">{duo.vibe}</p>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={(e) => handleAuditionDuo(e, duo)}
                          className="p-1 rounded-md bg-zinc-800 hover:bg-amber-500 text-zinc-400 hover:text-zinc-950 transition-colors"
                          title="Audition duo greeting"
                        >
                          {isAuditioning ? (
                            <Square className="w-3 h-3 fill-current text-amber-400" />
                          ) : (
                            <Play className="w-3 h-3 fill-current" />
                          )}
                        </button>
                        <span className="text-[10px] font-mono text-zinc-500 hidden sm:inline">
                          {duo.host1Voice} & {duo.host2Voice}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* 3. Ambient Soundtrack Vibe */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
              <Music className="w-3.5 h-3.5 text-amber-500" />
              <span>Background Soundtrack</span>
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              {[
                { id: 'lofi-chill', label: 'Lo-Fi Chill' },
                { id: 'ambient-noir', label: 'Ambient Noir' },
                { id: 'tech-minimal', label: 'Tech Minimal' },
                { id: 'cinematic-pulse', label: 'Cinematic Pulse' },
                { id: 'coffeehouse-acoustic', label: 'Acoustic Jazz' },
                { id: 'off', label: 'Voice Only' },
              ].map((v) => (
                <button
                  key={v.id}
                  type="button"
                  disabled={isGenerating}
                  onClick={() => setMusicVibe(v.id as MusicVibe)}
                  className={`p-2 rounded-xl border text-xs text-left transition-colors ${
                    musicVibe === v.id
                      ? 'bg-amber-500/15 border-amber-500/50 text-amber-300 font-medium'
                      : 'bg-zinc-950/40 border-zinc-800/80 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
                  }`}
                >
                  {v.label}
                </button>
              ))}
            </div>
            <p className="text-[10px] text-zinc-500 font-mono">
              Auto-ducks smoothly during host speech
            </p>
          </div>
        </div>

        {/* Synthesis Latency & Realism Mode Selection */}
        <div className="pt-2 border-t border-zinc-800/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-zinc-950/40 p-3 rounded-xl border border-zinc-800/50">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-500" />
            <div>
              <p className="text-xs font-semibold text-zinc-200">Synthesis Engine & Latency</p>
              <p className="text-[10px] text-zinc-500 font-mono">
                {synthesisMode === 'low-latency'
                  ? 'Sub-2s Fast-Track playback via Flash-Lite pipeline'
                  : 'Studio Master with vocal bursts (<laugh>, <breath>) & backchannels (|yeah|)'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 bg-zinc-900 p-0.5 rounded-lg border border-zinc-800">
            <button
              type="button"
              onClick={() => setSynthesisMode('low-latency')}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-all ${
                synthesisMode === 'low-latency'
                  ? 'bg-amber-500 text-zinc-950 font-bold'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              ⚡ Low Latency (~1-2s)
            </button>
            <button
              type="button"
              onClick={() => setSynthesisMode('studio-master')}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-all ${
                synthesisMode === 'studio-master'
                  ? 'bg-amber-500 text-zinc-950 font-bold'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              🎙️ Studio Master
            </button>
          </div>
        </div>

        {/* Generate Button & Progress State */}
        <div className="pt-2">
          {isGenerating ? (
            <div className="p-4 rounded-xl bg-zinc-950/80 border border-amber-500/30 flex items-center gap-3 animate-pulse">
              <Loader2 className="w-5 h-5 text-amber-500 animate-spin" />
              <div className="flex-1">
                <p className="text-xs font-semibold text-zinc-200">
                  {generationStep || 'Synthesizing Neural Radio Show...'}
                </p>
                <p className="text-[11px] text-zinc-500 font-mono mt-0.5">
                  AMOGH RESONANCE 104.7 FM • Real Neural Voice Engine Active
                </p>
              </div>
            </div>
          ) : (
            <button
              type="submit"
              disabled={!topic.trim()}
              className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-bold text-sm tracking-wide shadow-xl shadow-amber-500/20 flex items-center justify-center gap-2 transition-all transform active:scale-[0.99] disabled:opacity-50 disabled:pointer-events-none cursor-pointer"
            >
              <Radio className="w-4 h-4" />
              <span>Broadcast on AMOGH RESONANCE (104.7 FM)</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </form>
    </div>
  );
};
