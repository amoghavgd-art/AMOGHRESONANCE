import React, { useState } from 'react';
import { User } from 'firebase/auth';
import { googleSignIn, logout } from '../lib/firebase';
import { Radio, LogOut, CheckCircle2, Waves, HardDrive } from 'lucide-react';

interface HeaderProps {
  user: User | null;
  hasDriveAccess: boolean;
  onOpenDriveModal?: () => void;
  onAuthSuccess?: (user: User, token: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  hasDriveAccess,
  onOpenDriveModal,
  onAuthSuccess,
}) => {
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const handleGoogleSignIn = async () => {
    try {
      setIsLoggingIn(true);
      const res = await googleSignIn();
      if (res && onAuthSuccess) {
        onAuthSuccess(res.user, res.accessToken);
      }
    } catch (err: any) {
      if (err?.code !== 'auth/popup-closed-by-user') {
        console.warn('Sign-in status:', err?.message || err);
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await logout();
      setShowProfileMenu(false);
    } catch (err) {
      console.error('Logout error:', err);
    }
  };

  return (
    <header className="w-full border-b border-zinc-800/80 bg-zinc-950/80 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand identity */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center shadow-lg shadow-amber-500/20 text-zinc-950 font-black">
            <Radio className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold tracking-tight text-zinc-100 text-base sm:text-lg">
                AMOGH RESONANCE
              </span>
              <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-semibold tracking-wider">
                104.7 FM
              </span>
            </div>
            <p className="text-[11px] text-zinc-400 tracking-wide hidden sm:block">
              Broadcast-Grade Neural Synthesis & NotebookLM Deep Dives
            </p>
          </div>
        </div>

        {/* Center Station Health & API status indicator */}
        <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-full bg-zinc-900/90 border border-zinc-800 text-xs font-mono">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-zinc-300 font-medium">Neural Core: Online</span>
          <span className="text-zinc-600">•</span>
          <span className="text-amber-400/90">Gemini 3.8 TTS</span>
          <span className="text-zinc-600">•</span>
          <span className="text-zinc-400">24kHz Stereo</span>
        </div>

        {/* Right Actions: Google Auth & Drive Status */}
        <div className="flex items-center gap-3">
          {/* Drive Import Shortcut if logged in */}
          {user && onOpenDriveModal && (
            <button
              type="button"
              onClick={onOpenDriveModal}
              className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs text-zinc-300 hover:text-zinc-100 transition-colors"
            >
              <HardDrive className="w-3.5 h-3.5 text-amber-400" />
              <span>Import Drive Notes</span>
            </button>
          )}

          {user ? (
            /* User profile avatar dropdown */
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowProfileMenu(!showProfileMenu)}
                className="flex items-center gap-2 p-1.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 transition-all"
              >
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName || 'User'}
                    className="w-7 h-7 rounded-full object-cover border border-zinc-700"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-amber-600/30 text-amber-300 font-semibold text-xs flex items-center justify-center">
                    {(user.displayName || user.email || 'U')[0].toUpperCase()}
                  </div>
                )}
                <span className="text-xs font-medium text-zinc-300 max-w-[110px] truncate hidden sm:inline">
                  {user.displayName?.split(' ')[0] || user.email}
                </span>
              </button>

              {showProfileMenu && (
                <div className="absolute right-0 mt-2 w-64 rounded-xl bg-zinc-900 border border-zinc-800 shadow-2xl p-3 z-50 text-xs animate-in fade-in slide-in-from-top-2">
                  <div className="pb-2.5 mb-2.5 border-b border-zinc-800">
                    <p className="font-semibold text-zinc-200 truncate">
                      {user.displayName || 'Signed In User'}
                    </p>
                    <p className="text-zinc-500 font-mono truncate text-[11px] mt-0.5">
                      {user.email}
                    </p>
                    {hasDriveAccess && (
                      <div className="mt-2 flex items-center gap-1.5 text-emerald-400 text-[11px]">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Google Drive Connected</span>
                      </div>
                    )}
                  </div>

                  {onOpenDriveModal && (
                    <button
                      type="button"
                      onClick={() => {
                        setShowProfileMenu(false);
                        onOpenDriveModal();
                      }}
                      className="w-full text-left flex items-center gap-2 px-2.5 py-2 rounded-lg text-zinc-300 hover:bg-zinc-800 transition-colors"
                    >
                      <HardDrive className="w-4 h-4 text-amber-400" />
                      <span>Browse Google Docs</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={handleSignOut}
                    className="w-full text-left flex items-center gap-2 px-2.5 py-2 rounded-lg text-rose-400 hover:bg-rose-500/10 transition-colors mt-1"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            /* Official Google Sign In button styled per Google guidelines */
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isLoggingIn}
              className="flex items-center gap-2.5 px-3.5 py-2 rounded-xl bg-white hover:bg-zinc-100 text-zinc-900 text-xs font-medium shadow-sm transition-all disabled:opacity-50 cursor-pointer"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>{isLoggingIn ? 'Connecting...' : 'Sign in with Google'}</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
