import React, { useState, useEffect } from 'react';
import { DriveFileItem } from '../types/broadcast';
import { getAccessToken } from '../lib/firebase';
import { FileText, Search, Loader2, X, RefreshCw, HardDrive, Check } from 'lucide-react';

interface GoogleDrivePickerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectDoc: (title: string, text: string) => void;
}

export const GoogleDrivePicker: React.FC<GoogleDrivePickerProps> = ({
  isOpen,
  onClose,
  onSelectDoc,
}) => {
  const [files, setFiles] = useState<DriveFileItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingContentId, setLoadingContentId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [error, setError] = useState<string | null>(null);

  const fetchFiles = async () => {
    try {
      setLoading(true);
      setError(null);
      const token = await getAccessToken();
      if (!token) {
        setError('Please sign in with Google to access your Google Drive documents.');
        setLoading(false);
        return;
      }

      const res = await fetch('/api/drive/files', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `HTTP ${res.status}`);
      }

      const data = await res.json();
      setFiles(data.files || []);
    } catch (err: any) {
      console.error('Failed to load drive files:', err);
      setError(err?.message || 'Unable to connect to Google Drive.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchFiles();
    }
  }, [isOpen]);

  const handleSelect = async (file: DriveFileItem) => {
    try {
      setLoadingContentId(file.id);
      const token = await getAccessToken();
      if (!token) return;

      const url = `/api/drive/file-content?fileId=${encodeURIComponent(
        file.id
      )}&mimeType=${encodeURIComponent(file.mimeType)}`;

      const res = await fetch(url, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!res.ok) {
        throw new Error('Failed to read file content.');
      }

      const data = await res.json();
      if (data.content) {
        onSelectDoc(file.name, data.content);
        onClose();
      }
    } catch (err: any) {
      console.error('Error importing file:', err);
      setError(err?.message || 'Failed to download file content.');
    } finally {
      setLoadingContentId(null);
    }
  };

  if (!isOpen) return null;

  const filteredFiles = files.filter((f) =>
    f.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-xl rounded-2xl bg-zinc-900 border border-zinc-800 shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <HardDrive className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-zinc-100">Import from Google Drive</h3>
              <p className="text-xs text-zinc-400">
                Choose a Google Doc or text note to transform into a radio show
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Refresh */}
        <div className="px-5 py-3 border-b border-zinc-800/60 bg-zinc-950/40 flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search documents by name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-amber-500/50"
            />
          </div>
          <button
            type="button"
            onClick={fetchFiles}
            disabled={loading}
            className="p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-zinc-200 transition-colors disabled:opacity-50"
            title="Refresh files"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Content list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2 min-h-[240px]">
          {loading && files.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-zinc-500 gap-2">
              <Loader2 className="w-6 h-6 animate-spin text-amber-500" />
              <span className="text-xs">Connecting to Google Drive...</span>
            </div>
          ) : error ? (
            <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs">
              <p className="font-semibold">Unable to access files</p>
              <p className="mt-1 text-rose-300/80">{error}</p>
            </div>
          ) : filteredFiles.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-zinc-500 gap-1 text-center">
              <FileText className="w-8 h-8 text-zinc-600 mb-1" />
              <p className="text-xs text-zinc-300 font-medium">No documents found</p>
              <p className="text-[11px] text-zinc-500 max-w-xs">
                Make sure you have Google Docs or text files in your connected Google account.
              </p>
            </div>
          ) : (
            filteredFiles.map((file) => {
              const isLoading = loadingContentId === file.id;
              const isGoogleDoc = file.mimeType.includes('document');

              return (
                <div
                  key={file.id}
                  onClick={() => !isLoading && handleSelect(file)}
                  className={`flex items-center justify-between p-3 rounded-xl border border-zinc-800/80 bg-zinc-900/50 hover:bg-zinc-800/60 hover:border-zinc-700 transition-all cursor-pointer group ${
                    isLoading ? 'opacity-70 pointer-events-none' : ''
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0 pr-2">
                    <div
                      className={`p-2 rounded-lg ${
                        isGoogleDoc
                          ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                          : 'bg-zinc-800 text-zinc-400'
                      }`}
                    >
                      <FileText className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-medium text-zinc-200 group-hover:text-amber-400 transition-colors truncate">
                        {file.name}
                      </p>
                      <p className="text-[10px] text-zinc-500 font-mono mt-0.5">
                        {isGoogleDoc ? 'Google Doc' : 'Plain Text'} •{' '}
                        {file.modifiedTime
                          ? new Date(file.modifiedTime).toLocaleDateString()
                          : 'Recent'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    {isLoading ? (
                      <Loader2 className="w-4 h-4 animate-spin text-amber-500" />
                    ) : (
                      <span className="text-[11px] px-2.5 py-1 rounded bg-zinc-800 text-zinc-300 group-hover:bg-amber-500 group-hover:text-zinc-950 font-medium transition-all">
                        Load
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-zinc-800 bg-zinc-950/60 flex items-center justify-between text-xs text-zinc-500">
          <span>Read-only Google Drive access</span>
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
